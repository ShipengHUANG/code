import pandas as pd
import numpy as np
import xlsxwriter
import warnings
from sklearn.linear_model import LinearRegression
from sklearn.cluster import KMeans
from warnings import simplefilter

simplefilter(action='ignore', category=FutureWarning)
warnings.filterwarnings("ignore")


def output(data):
    file = 'MacroForecasting_result.xlsx'
    workbook = xlsxwriter.Workbook(file)  # 建立文件
    worksheet = workbook.add_worksheet()
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            worksheet.write(i, j, data.iloc[i, j])
    workbook.close()


# 备选指数选择
def getGroup(dfIndex, level1):
    indexCodes = list(dfIndex.columns)
    indexCodes.remove(level1)
    km = KMeans(n_clusters=5)
    t = dfIndex
    km.fit(t.loc[:, indexCodes].values.transpose())
    srsRet = pd.Series(km.labels_, index=indexCodes)
    # print(srsRet)
    lstGroup0, lstGroup1, lstGroup2, lstGroup3, lstGroup4 = list(srsRet[srsRet == 0].index), \
                                                            list(srsRet[srsRet == 1].index), \
                                                            list(srsRet[srsRet == 2].index), \
                                                            list(srsRet[srsRet == 3].index), \
                                                            list(srsRet[srsRet == 4].index)
    srsCorr = dfIndex.corr()[level1]
    select0 = pd.to_numeric(srsCorr[lstGroup0]).argmin()
    select1 = pd.to_numeric(srsCorr[lstGroup1]).argmin()
    select2 = pd.to_numeric(srsCorr[lstGroup2]).argmin()
    select3 = pd.to_numeric(srsCorr[lstGroup3]).argmin()
    select4 = pd.to_numeric(srsCorr[lstGroup4]).argmin()
    return select0, select1, select2, select3, select4, lstGroup0, lstGroup1, lstGroup2, lstGroup3, lstGroup4


def lagrange(x, y):
    n = len(x)
    m = len(y)
    if n != m:
        print("len(x)不等于len(y)")
        return
    else:
        p = np.poly1d([0])
        for k in range(n):
            L = np.poly1d([1])
            for i in range(n):
                if i != k:
                    L = L * np.poly1d([1.0 / (x[k] - x[i]), -float(x[i] / (x[k] - x[i]))])
            p = p + L * y[k]
        return p


def lagrange_value(data, k=5):
    data_copy = data.copy(deep=True)
    for col in data_copy.columns:
        col_data = data_copy[col]
        col_data_nan = col_data[col_data.isnull()]
        col_data_nan_list = col_data_nan.index
        for n in col_data_nan_list:
            list_1 = list(range(n - k, n))
            if list_1[0] < col_data.index[0]:
                list_1 = list(range(col_data.index[0], n))
            list_2 = col_data[n:]
            list_2 = list_2[list_2.notnull()]
            list_2 = list(list_2[0:k].index)
            y = col_data[list_1 + list_2]
            data_copy[col][n] = lagrange(y.index, list(y))(n)
    return data_copy


# **********************************************************************************************************************

# 固定选择Level1指标为宏观指标本身滞后项
# # 根据备注，对应修改line45引号中Lag1前面的部分
def findLevel1(dfIndex, srsNav):
    L = LinearRegression(fit_intercept=True)
    idCode = "社融 Lag1"  # PMI /CPI /PPI /进口量 /出口量 /社融 /新增信贷 /社零 /工业增加值 /固定资产投资 /房地产投资 /基建投资 /制造业投资
    srsIndex = dfIndex[idCode]
    L.fit(srsIndex.values.reshape(-1, 1), srsNav.values.reshape(-1, 1))
    level1, alpha, beta = idCode, L.intercept_[0], L.coef_[0][0]

    return level1, alpha, beta

# 导入高频指标数据
# # 在line54的sheet_name参数中修改对应指标池(VAL/CPI/PPI/TRA/PER)并添加对应周数(1/4/3/2)
w = pd.DataFrame(pd.read_excel('MacroForecasting_data.xlsx', sheet_name='VAL1', header=3,
                               index_col=0))  # VAL/ CPI/ PPI/ TRA/TRA/ VAL/VAL/ PER/PER/PER/PER/PER/PER + 1234
w = w.iloc[::-1]
w = w.reset_index(drop=True)  # 高频数据

# 导入月度宏观指标数据
# # 修改line61中usecols参数为对应宏观变量缩写
v = pd.DataFrame(pd.read_excel('MacroForecasting_data.xlsx', sheet_name='month', header=3,
                               usecols=['FIN']))  # PMI/ CPI/ PPI/ IMP/EXP/ FIN/CRE/ RET/IND/FIX/FIX_FC/FIX_JJ/FIX_ZZ

# **********************************************************************************************************************

v = v.iloc[::-1]
v = v.reset_index(drop=True)  # 月度数据
Forecast = []
# 寻找最佳基金组合
for i in range(40, v.shape[0] - 2):  # 预测周减二；非预测周减三
    dfIndex = w.iloc[i + 2 - 36:i + 2]  # 初始两行变量
    srsNav = v.iloc[i + 2 - 36:i + 2]  # 初始两行变量

    # 寻找哪个才是该基金的主要指数
    level1, alpha, beta = findLevel1(dfIndex, srsNav)

    # 将各指数用KMeans分2组，并找到各组与Level相关系数最低的那一个指数
    select0, select1, select2, select3, select4, lstGroup0, lstGroup1, lstGroup2, lstGroup3, lstGroup4 = getGroup(
        dfIndex, level1)

    # 用剩余的四种风格去回归掉残差
    cols = dfIndex.columns
    dfX = dfIndex.loc[:,
          [lstGroup0[select0], lstGroup1[select1], lstGroup2[select2], lstGroup3[select3], lstGroup4[select4]]]
    for sel in (lstGroup0[select0], lstGroup1[select1], lstGroup2[select2], lstGroup3[select3], lstGroup4[select4]):
        dfX[sel] -= dfIndex[level1]

    y = srsNav[srsNav.columns[0]] - beta * dfIndex[level1] - alpha

    LineFinal = LinearRegression(fit_intercept=True)
    LineFinal.fit(dfX.values, y)
    # 整理最后结果，输出alpha，beta1，beta2，beta3, beta4, beta5
    srsRet = pd.Series(
        index=["alpha", level1, lstGroup0[select0], lstGroup1[select1], lstGroup2[select2], lstGroup3[select3],
               lstGroup4[select4]])

    srsRet["alpha"] = alpha + LineFinal.intercept_
    srsRet[level1] = beta - sum(LineFinal.coef_)
    srsRet.loc[[lstGroup0[select0], lstGroup1[select1], lstGroup2[select2], lstGroup3[select3],
                lstGroup4[select4]]] = LineFinal.coef_

    Estimation = srsRet["alpha"] + srsRet[level1] * w.loc[i + 3, [level1]] \
                 + srsRet[lstGroup0[select0]] * w.loc[i + 3, lstGroup0[select0]] \
                 + srsRet[lstGroup1[select1]] * w.loc[i + 3, lstGroup1[select1]] \
                 + srsRet[lstGroup2[select2]] * w.loc[i + 3, lstGroup2[select2]] \
                 + srsRet[lstGroup3[select3]] * w.loc[i + 3, lstGroup3[select3]] \
                 + srsRet[lstGroup4[select4]] * w.loc[i + 3, lstGroup4[select4]]

    Forecast.append(Estimation)

# 导出数据
Result = pd.DataFrame(np.array(Forecast))
Result = Result.iloc[::-1]
Result = Result.reset_index(drop=True)
output(Result)
print(srsRet)
print(Result.iloc[0, 0])
