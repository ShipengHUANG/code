'''
本代码的用途：
1.计算选择的基金在(start,end)期间每天的久期，存入工作表'fundduration'中，需要手动补充选择的基金代码和日期
2.将选择的基金在(start,end)期间每天对应的最优指数代码level1及level1的拟合系数β存入工作表‘level1’中，需要手动补充选择的日期
其中，‘data2.xlsx’的第4个工作表‘code’里为选择的基金
'''

import numpy as np
import pandas as pd
import xlsxwriter
import warnings
import time
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression
from warnings import simplefilter

simplefilter(action='ignore', category=FutureWarning)
warnings.filterwarnings("ignore")
time_begin = time.time()

# start为Excel中选择的起始日对应的行数，end为Excel中选择的结束日对应的行数，可进行修改调试
start = 1923
end = 1925


# Excel函数，用来将最终输出的结果写入Excel文件'result2.xlsx'中，'fundduration'工作表需要手动补充对应的基金代码（‘data2.xlsx’的第4个工作表‘code’里为选择的基金代码）和日期（start和end对应的日期）
def output(data1, data2, data3):
    file = 'mltfd_result_python.xlsx'
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})  # 建立Excel文件
    worksheet1 = workbook.add_worksheet('fundduration')  # 建立基金久期工作表‘fundduration’
    worksheet2 = workbook.add_worksheet('level1')  # 建立最优指数工作表'level1'
    for i in range(data1.shape[0]):
        for j in range(data1.shape[1]):
            worksheet1.write(i, j, data1.iloc[i, j])
    for i in range(data2.shape[0]):
        for j in range(data2.shape[1]):
            worksheet2.write(i + 1, j, data2.iloc[i, j])
    for i in range(data3.shape[0]):
        for j in range(data3.shape[1]):
            worksheet2.write(i, j, data3.iloc[i, j])
    workbook.close()


# 建立类
class fundDuration(object):
    # 定义属性
    def __init__(self, codes, start, end, getNavRtSlice, getBondIndexSlice, getBondDurSlice, rol=8):  # codes的类型：实参传递为list
        # 基金代码，起始日、结束日，回归窗口区间、滚动长度
        self.codes = codes
        self.start, self.end = start, end
        self.rol = rol

        self.dfNavRt = getNavRtSlice  # 读入对应净值代码（一个代码）的净值
        self.dfIndex = getBondIndexSlice  # 读入债券指数涨跌幅工作表的所有值

        self.dfNavRtRoll = self.dfNavRt.rolling(rol).sum()  # 获取基金净值波幅表（每8天进行1次加总，前7个值会是NAN）
        self.dfIndexRoll = self.dfIndex.rolling(rol).sum()  # 获取债券指数变动波幅表（每8天进行1次加总，前7个值会是NAN）

        self.dfDur = getBondDurSlice  # 读入债券指数久期表

    # 最优指数选择
    def _getSlice(self, code, date, n):
        # 选择符合条件的对应日期的净值和指数切片数据，其中传入的实参n=55
        srsNav = self.dfNavRtRoll[code].iloc[date - n:date]  # r传入date，[r-55：r）日
        dfIndex = self.dfIndexRoll.iloc[date - n:date]
        _t = srsNav.apply(np.abs).iloc[:, 0] <= dfIndex.applymap(pd.np.abs).max(
            axis=1) * 3  # 后者为series，值为每一行最大的数（当日所有指数波幅的最大数）的3倍
        ids = _t[_t].index
        if any(srsNav.isnull().any(axis=1)):
            return None, None
        else:
            return srsNav.loc[ids], dfIndex.loc[ids]

    def findLevel1(self, dfIndex, srsNav):
        # 用回归的方式寻找出对srsNav回归效果最好的指数，返回回归效果最好的指数代码level1，一阶线性回归下的alpha与beta
        L = LinearRegression(fit_intercept=True)
        indexCodes = dfIndex.columns  # 所有指数的代码

        score, alpha, beta = 0, None, None

        for idCode in indexCodes:
            srsIndex = dfIndex[idCode]

            L.fit(srsIndex.values.reshape(-1, 1), srsNav.values.reshape(-1, 1))
            if L.score(srsIndex.values.reshape(-1, 1), srsNav.values.reshape(-1, 1)) >= score:
                score = L.score(srsIndex.values.reshape(-1, 1), srsNav.values.reshape(-1, 1))
                level1, alpha, beta = idCode, L.intercept_[0], L.coef_[0][0]

        return level1, alpha, beta

    # 备选指数选择
    def _getGroup(self, dfIndex, level1):
        indexCodes = list(dfIndex.columns)
        indexCodes.remove(level1)

        km = KMeans(n_clusters=2)
        t = dfIndex / dfIndex.std()
        km.fit(t.loc[:, indexCodes].values.transpose())  # transpose()转置
        srsRet = pd.Series(km.labels_, index=indexCodes)
        lstGroup0, lstGroup1 = list(srsRet[srsRet == 0].index), list(srsRet[srsRet == 1].index)  # 2个聚类

        srsCorr = dfIndex.corr()[level1]
        select0 = pd.to_numeric(srsCorr[lstGroup0]).argmin()  # 挑出相关系数最小的索引位置
        select1 = pd.to_numeric(srsCorr[lstGroup1]).argmin()

        return select0, select1, lstGroup0, lstGroup1

    # 最终回归
    def regForSingleDaySingleCode(self, code, date, n=55):
        # 返回srsRet，为Series，内容为截距项alpha及alpha的值，最优指数代码及其系数β，2个备选指数代码及其系数β0、β1
        srsNav, dfIndex = self._getSlice(code, date, n)  # 取滚动回归要的样本
        if srsNav is None:
            return None

        else:
            # 寻找哪个才是该基金的主要指数
            level1, alpha, beta = self.findLevel1(dfIndex, srsNav)

            # 将各指数用KMeans分2组，并找到各组与Level1相关系数最低的那一个指数
            select0, select1, lstGroup0, lstGroup1 = self._getGroup(dfIndex, level1)

            # 用剩余的两种风格去回归掉残差
            dfX = dfIndex.loc[:, [lstGroup0[select0], lstGroup1[select1]]]
            for sel in (lstGroup0[select0], lstGroup1[select1]):
                dfX[sel] -= dfIndex[level1]

            y = srsNav[srsNav.columns[0]] - beta * dfIndex[level1] - alpha

            LineFinal = LinearRegression(fit_intercept=True)
            LineFinal.fit(dfX.values, y)
            # 整理最后结果，输出alpha，beta1，beta2，beta3
            srsRet = pd.Series(index=["alpha", level1, lstGroup0[select0], lstGroup1[select1]])
            a = alpha
            aa = LineFinal.intercept_
            aaa = sum(LineFinal.coef_)

            srsRet["alpha"] = alpha + LineFinal.intercept_
            srsRet[level1] = beta - sum(LineFinal.coef_)
            srsRet.loc[[lstGroup0[select0], lstGroup1[select1]]] = LineFinal.coef_

            return srsRet

    # 有效波动的认定和最终输出久期
    def calcDur(self, code, srsRet, date):
        # srsRet是regForSingleDaySingleCode的返回值，date为日期数据
        if srsRet is None:
            return None
        else:
            lstIndexes = list(srsRet.index[1:])  # 3个指数代码
            durS = (self.dfDur.loc[date, lstIndexes] * srsRet[lstIndexes]).sum()
            global ratio
            absFenmu = 0.0
            for num in range(13, 60):
                # 从13开始寻找有效波动值
                i = self.dfNavRt.index.get_loc(date)
                if i >= num:
                    numDaysBefore = self.dfNavRt.index[i - num]
                    fenmu = (self.dfIndex.loc[numDaysBefore:date, lstIndexes] * srsRet[lstIndexes]).sum().sum()
                    if abs(fenmu) > 0.4:
                        ratio = (self.dfNavRt.loc[numDaysBefore:date, code].sum() - srsRet.alpha * num / float(
                            self.rol)) / fenmu

                        break
                    elif abs(fenmu) > absFenmu:
                        ratio = (self.dfNavRt.loc[numDaysBefore:date, code].sum() - srsRet.alpha * num / float(
                            self.rol)) / fenmu
                        absFenmu = abs(fenmu)
                else:
                    print(u"疑似没有有效波动，ratio强制设为期间波动最大时的水平")

            durRet = 100 * durS * ratio

            return durRet


# 主程序
code = pd.DataFrame(pd.read_excel('mltfd_data_python.xlsx', sheet_name='Code', header=3, index_col=0))

start = start - 5
end = end - 4

resultc = []
Best = pd.DataFrame(np.random.randn(end - start, (
    code.shape[0]) * 2))  # Best用来存放选择的基金在(start,end)期间每天对应的最优指数代码level1及level1的拟合系数β（不含选择的基金）
NavCodes = pd.DataFrame(
    np.random.randn(1, (code.shape[0]) * 2))  # Excel中无法将未经合并的单元格一分为二且拆分出来的两个单元格内容相同，故在此批量处理，作为工作表‘level1’的表头（基金代码）

getNavRt = pd.DataFrame(pd.read_excel('mltfd_data_python.xlsx', sheet_name='NavRt', header=3))
getBondIndex = pd.DataFrame(pd.read_excel('mltfd_data_python.xlsx', sheet_name='BondIndex', header=3))
getBondDur = pd.DataFrame(pd.read_excel('mltfd_data_python.xlsx', sheet_name='BondDur', header=3))

for c in range(code.shape[0]):
    resultr = []
    f = code.iloc[c, 0]  # f为读入的code工作表中的基金代码（单个代码）,str

    getNavRtSlice = getNavRt.loc[:, [f]]
    getBondIndexSlice = getBondIndex.loc[:]
    getBondDurSlice = getBondDur.loc[:]


    fund = fundDuration([f], start, end, getNavRtSlice, getBondIndexSlice, getBondDurSlice)

    for r in range(start, end):
        srsRet = fund.regForSingleDaySingleCode(fund.codes, r,
                                                n=55)  # srsRet为Series：截距项alpha及alpha的值，最优指数代码及其系数β，2个备选指数代码及其系数β0、β1
        durRet = fund.calcDur(fund.codes, srsRet, r)  # durRet为单只基金f在第r天的久期
        resultr.append(durRet)  # 单只基金f在(start,end)期间每天的久期，list
        if srsRet is None:
            Best.iloc[r - start, 2 * c] = None
            Best.iloc[r - start, 2 * c + 1] = None
            print('第', c + 1, '只基金', '跳过', '/', range(start, end))
        else:
            Best.iloc[r - start, 2 * c] = srsRet.index[1]
            Best.iloc[r - start, 2 * c + 1] = srsRet[1]
            print('第', c + 1, '只基金', r, '/', range(start, end))
    NavCodes.iloc[0, 2 * c] = code.iloc[c, 0]
    NavCodes.iloc[0, 2 * c + 1] = code.iloc[c, 0]
    resultr = np.array(resultr).reshape(-1)  # 变成1维数组，否则后面转成pandas会报错
    resultc.append(resultr)

Result = pd.DataFrame(np.array(resultc, dtype=np.float)).T
output(Result, Best, NavCodes)
time_end = time.time()
time = (time_end - time_begin) / 60
print('程序运行时间:', time, 'mins')
