# -------------------------------------------------Libraries
import numpy as np
import warnings
import pandas as pd
import xlsxwriter
from statsmodels.stats.diagnostic import acorr_ljungbox
warnings.filterwarnings('ignore')

def output(data1, data2, data3):
    file = 'RQselect/Results.xlsx'
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})
    worksheet1 = workbook.add_worksheet('Correl')
    worksheet2 = workbook.add_worksheet('Test')
    worksheet3 = workbook.add_worksheet('Correl_Test')

    for col_num, value in enumerate(data1.columns.values):
        worksheet1.write(0, col_num + 1, value)

    for row_num, value in enumerate(data1.index):
        worksheet1.write(row_num + 1, 0, value)

    for i in range(data1.shape[0]):
        for j in range(data1.shape[1]):
            worksheet1.write(i + 1, j + 1, data1.iloc[i, j])

    for col_num, value in enumerate(data2.columns.values):
        worksheet2.write(0, col_num + 1, value)

    for row_num, value in enumerate(data2.index):
        worksheet2.write(row_num + 1, 0, value)

    for i in range(data2.shape[0]):
        for j in range(data2.shape[1]):
            worksheet2.write(i + 1, j + 1, data2.iloc[i, j])

    for col_num, value in enumerate(data3.columns.values):
        worksheet3.write(0, col_num + 1, value)

    for row_num, value in enumerate(data3.index):
        worksheet3.write(row_num + 1, 0, value)

    for i in range(data3.shape[0]):
        for j in range(data3.shape[1]):
            worksheet3.write(i + 1, j + 1, data3.iloc[i, j])

    workbook.close()

def KalmanFilter(z, RQ, n_iter=20):
    # 这里是假设A=1，H=1的情况
    # intial parameters

    sz = (n_iter,)  # size of array

    # process variance
    Q = 0.0001

    # allocate space for arrays
    xhat = np.zeros(sz)  # a posteri estimate of x
    P = np.zeros(sz)  # a posteri error estimate
    xhatminus = np.zeros(sz)  # a priori estimate of x
    Pminus = np.zeros(sz)  # a priori error estimate
    K = np.zeros(sz)  # gain or blending factor

    # estimate of measurement variance, change to see effect
    R = RQ * Q

    # intial guesses
    xhat[0] = 0.0
    P[0] = 1.0
    A = 1
    H = 1

    for k in range(1, n_iter):
        # time update
        xhatminus[k] = A * xhat[k - 1]  # X(k|k-1) = AX(k-1|k-1) + BU(k) + W(k),A=1,BU(k) = 0
        Pminus[k] = A * P[k - 1] + Q  # P(k|k-1) = AP(k-1|k-1)A' + Q(k) ,A=1

        # measurement update
        K[k] = Pminus[k] / (Pminus[k] + R)  # Kg(k)=P(k|k-1)H'/[HP(k|k-1)H' + R],H=1
        xhat[k] = xhatminus[k] + K[k] * (z[k] - H * xhatminus[k])  # X(k|k) = X(k|k-1) + Kg(k)[Z(k) - HX(k|k-1)], H=1
        P[k] = (1 - K[k] * H) * Pminus[k]  # P(k|k) = (1 - Kg(k)H)P(k|k-1), H=1
    return xhat

def RQselect(r2,p5):
    p2 = r2  # 测试的卡尔曼滤波参数
    p5 = p5  # 数据文件名称
    # -------------------------------------------------Loading data
    # 变量设定
    kalman_index = p2
    dict1 = {'RQ': [], 'num1': [], 'num2': [], 'num3': [], 'num4': []}
    dict2 = {'RQ': [], 'test': [], 'result': []}

    # 数据读取
    Fluc = pd.read_excel(p5, sheet_name='波动', header=0, index_col=0)
    df_rate = pd.read_excel(p5, sheet_name='利率', header=0, index_col=0)
    fluc_ind = pd.DataFrame(Fluc)

    # 卡尔曼滤波
    for ii in range(0, len(kalman_index)):
        trend = KalmanFilter(df_rate['rate'], kalman_index[ii], n_iter=len(df_rate))[1:]
        fluc = df_rate['rate'].tolist()[1:] - trend
        df_fluc = pd.DataFrame(fluc.transpose(), columns=['fluc'], index=df_rate.index[1:])

        # 1、相关性筛选法(correl)
        df_fluc = pd.concat([df_fluc, fluc_ind.shift(1)], axis=1).interpolate().dropna()
        corr_fluc = abs(df_fluc.corr())
        fluc_num1 = corr_fluc['fluc'][corr_fluc['fluc'] > 0.7].count() - 1
        fluc_num2 = corr_fluc['fluc'][corr_fluc['fluc'] > 0.6].count() - 1
        fluc_num3 = corr_fluc['fluc'][corr_fluc['fluc'] > 0.5].count() - 1
        fluc_num4 = corr_fluc['fluc'][corr_fluc['fluc'] > 0.4].count() - 1

        dict1['RQ'].append(kalman_index[ii])
        dict1['num1'].append(fluc_num1)
        dict1['num2'].append(fluc_num2)
        dict1['num3'].append(fluc_num3)
        dict1['num4'].append(fluc_num4)

        # 2、白噪声检验法-放大修正版(test)
        lb_pvalues = acorr_ljungbox(df_fluc['fluc'], lags=24)['lb_pvalue']
        if max(lb_pvalues)*1e+132 <= 0.05:
            white = 0
        else:
            white = 1
        a = max(lb_pvalues)*1e+132
        dict2['RQ'].append(kalman_index[ii])
        dict2['test'].append(max(lb_pvalues)*1e+132)
        dict2['result'].append(white)


    # 导出相关性分析结果和前几备选指标
    correl = pd.DataFrame(dict1)
    correl.columns = ['RQ', '>0.7', '>0.6', '>0.5', '>0.4']
    correl = correl.sort_values(by='>0.7', ascending=False)
    correl = correl.reset_index(drop=True)

    test = pd.DataFrame(dict2)
    test.columns = ['RQ','lb-pvalue','white?']
    test = test.sort_values(by='lb-pvalue', ascending=True)
    test = test.reset_index(drop=True)

    sub_correl = correl[correl['>0.7'] >= 1]
    sub_test = test[test['white?'] == 0]
    correl_test = pd.merge(sub_correl, sub_test, on=['RQ'], how='inner')

    output(correl, test, correl_test)

