# -------------------------------------------------Libraries
import xlsxwriter

def output(m1, m2, m3, m4, m5, m6, m7, m8, df1, df2, df3, df4, df5, df6, df7, df8):
    file = 'Summary.xlsx'
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})
    worksheet1 = workbook.add_worksheet('Summary')

    worksheet1.write(0, 0, 'Method1：VAR，不锁定模块，不处理共线性')
    worksheet1.write(13, 0, 'Method2：VAR，不锁定模块，处理共线性')
    worksheet1.write(26, 0, 'Method3：VAR，锁定模块')
    worksheet1.write(39, 0, 'Method4：Method2的逐步回归法，第二步最远变量回归残差')
    worksheet1.write(52, 0, 'Method5：Logistic 滚动回归')
    worksheet1.write(65, 0, 'Method6：Logistic 一次长回归')
    worksheet1.write(78, 0, 'Method7：Logistic 01设置滚动回归')
    worksheet1.write(91, 0, 'Method8：Logistic woe分箱一次长回归')

    if m1 == 1:

        for col_num, value in enumerate(df1.columns.values):
            worksheet1.write(0, col_num + 1, value)

        for row_num, value in enumerate(df1.index):
            worksheet1.write(row_num + 1, 0, value)

        for i in range(df1.shape[0]):
            for j in range(df1.shape[1]):
                worksheet1.write(i + 1, j + 1, df1.iloc[i, j])

    if m2 == 1:
        for col_num, value in enumerate(df2.columns.values):
            worksheet1.write(13, col_num + 1, value)

        for row_num, value in enumerate(df2.index):
            worksheet1.write(row_num + 14, 0, value)

        for i in range(df2.shape[0]):
            for j in range(df2.shape[1]):
                worksheet1.write(i + 14, j + 1, df2.iloc[i, j])

    if m3 == 1:
        for col_num, value in enumerate(df3.columns.values):
            worksheet1.write(26, col_num + 1, value)

        for row_num, value in enumerate(df3.index):
            worksheet1.write(row_num + 27, 0, value)

        for i in range(df3.shape[0]):
            for j in range(df3.shape[1]):
                worksheet1.write(i + 27, j + 1, df3.iloc[i, j])

    if m4 == 1:

        for col_num, value in enumerate(df4.columns.values):
            worksheet1.write(39, col_num + 1, value)

        for row_num, value in enumerate(df4.index):
            worksheet1.write(row_num + 40, 0, value)

        for i in range(df4.shape[0]):
            for j in range(df4.shape[1]):
                worksheet1.write(i + 40, j + 1, df4.iloc[i, j])

    if m5 == 1:
        for col_num, value in enumerate(df5.columns.values):
            worksheet1.write(52, col_num + 1, value)

        for row_num, value in enumerate(df5.index):
            worksheet1.write(row_num + 53, 0, value)

        for i in range(df5.shape[0]):
            for j in range(df5.shape[1]):
                worksheet1.write(i + 53, j + 1, df5.iloc[i, j])

    if m6 == 1:
        for col_num, value in enumerate(df6.columns.values):
            worksheet1.write(65, col_num + 1, value)

        for row_num, value in enumerate(df6.index):
            worksheet1.write(row_num + 66, 0, value)

        for i in range(df6.shape[0]):
            for j in range(df6.shape[1]):
                worksheet1.write(i + 66, j + 1, df6.iloc[i, j])

    if m7 == 1:
        for col_num, value in enumerate(df7.columns.values):
            worksheet1.write(78, col_num + 1, value)

        for row_num, value in enumerate(df7.index):
            worksheet1.write(row_num + 79, 0, value)

        for i in range(df7.shape[0]):
            for j in range(df7.shape[1]):
                worksheet1.write(i + 79, j + 1, df7.iloc[i, j])

    if m8 == 1:
        for col_num, value in enumerate(df8.columns.values):
            worksheet1.write(91, col_num + 1, value)

        for row_num, value in enumerate(df8.index):
            worksheet1.write(row_num + 92, 0, value)

        for i in range(df8.shape[0]):
            for j in range(df8.shape[1]):
                worksheet1.write(i + 92, j + 1, df8.iloc[i, j])
    workbook.close()
