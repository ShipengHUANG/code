# -------------------------------------------------Libraries
import time
import warnings
import numpy as np
import pandas as pd
from RQselect import RQselect
from Method1 import Method1
from Method2 import Method2
from Method3 import Method3
from Method4 import Method4
from Method5 import Method5
from Method6 import Method6
from Method7 import Method7
from Method8 import Method8
from Function import output
warnings.filterwarnings('ignore')
time_begin = time.time()

# -------------------------------------------------控制面板,调整五个参数
p1 = 0.8  # 训练集比例
p2 = [10000, 5000, 1000, 500]  # 测试的卡尔曼滤波参数，全集为 [10000, 5000, 1000, 500, 100, 50, 10, 5, 1, 0.50, 0.10, 0.05]
p3 = 10  # 选择与趋势和滤波相关性前p3的变量
p4 = 5  # 应选出的指标数
p5 = 'Data/Data5.xlsx'  # 数据文件名称
# -------------------------------------------------运行方法参数
m1 = 0  # 是否运行Method1 [0=不运行；1=运行]
m2 = 0  # 是否运行Method2 [0=不运行；1=运行]
m3 = 0  # 是否运行Method3 [0=不运行；1=运行]
m4 = 0  # 是否运行Method4 [0=不运行；1=运行]
m5 = 0  # 是否运行Method5 [0=不运行；1=运行]
m6 = 0  # 是否运行Method6 [0=不运行；1=运行]
m7 = 1  # 是否运行Method7 [0=不运行；1=运行]
m8 = 0  # 是否运行Method8 [0=不运行；1=运行]
# -------------------------------------------------是否滤波参数测试？
r1 = 0  # 是否运行滤波参数选择代码？[选1进入滤波测试模式后，仅会运行滤波参检测]
r2 = np.linspace(0, 10000,num= 1000,endpoint=True)  # 测试的卡尔曼滤波参数
# -------------------------------------------------Main

if r1 == 1:
    RQselect.RQselect(r2,p5)
else:
    df1 = pd.DataFrame()
    df2 = pd.DataFrame()
    df3 = pd.DataFrame()
    df4 = pd.DataFrame()
    df5 = pd.DataFrame()
    df6 = pd.DataFrame()
    df7 = pd.DataFrame()
    df8 = pd.DataFrame()

    if m1 == 1:
        df1 = Method1.RunTest(p1,p2,p3,p4,p5)
    if m2 == 1:
        df2 = Method2.RunTest(p1,p2,p3,p4,p5)
    if m3 == 1:
        df3 = Method3.RunTest(p1,p2,p5)
    if m4 == 1:
        df4 = Method4.RunTest(p1,p2,p3,p4,p5)
    if m5 == 1:
        df5 = Method5.RunTest(p1,40,p5)
    if m6 == 1:
        df6 = Method6.RunTest(p1,40,p5)
    if m7 == 1:
        df7 = Method7.RunTest(p1,6,p5)
    if m8 == 1:
        df8 = Method8.RunTest(p1,40,p5)
    output.output(m1,m2,m3,m4,m5,m6,m7,m8,df1,df2,df3,df4,df5,df6,df7,df8)

    # -------------------------------------------------Timer
    time_end = time.time()
    time = (time_end - time_begin) / 60
    print('程序运行时间:', time, 'mins')
