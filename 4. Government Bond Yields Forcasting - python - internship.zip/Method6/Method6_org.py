# -------------------------------------------------Libraries
import numpy as np
import pandas as pd
import xlsxwriter
import time
import math
import warnings
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split


# -------------------------------------------------Functions
def output(data_variables, df6, result):
    file = 'Method6/Results.xlsx'
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})
    worksheet1 = workbook.add_worksheet('Notes')
    worksheet2 = workbook.add_worksheet('Results')
    worksheet3 = workbook.add_worksheet('Details')
    date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})

    for col_num, value in enumerate(data_variables.columns.values):
        worksheet1.write(0, col_num + 1, value)

    for row_num, value in enumerate(data_variables.index):
        worksheet1.write(row_num + 1, 0, value)

    for i in range(data_variables.shape[0]):
        for j in range(data_variables.shape[1]):
            worksheet1.write(i + 1, j + 1, data_variables.iloc[i, j])

    for col_num, value in enumerate(result.columns.values):
        worksheet2.write(0, col_num + 1, value)

    for row_num, value in enumerate(result.index):
        worksheet2.write(row_num + 1, 0, value)

    for i in range(result.shape[0]):
        for j in range(result.shape[1]):
            worksheet2.write(i + 1, j + 1, result.iloc[i, j])

    for col_num, value in enumerate(df6.columns.values):
        worksheet3.write(0, col_num + 1, value)

    for row_num, value in enumerate(df6.index):
        worksheet3.write(row_num + 1, 0, value, date_format)

    for i in range(df6.shape[0]):
        for j in range(df6.shape[1]):
            worksheet3.write(i + 1, j + 1, df6.iloc[i, j])

    workbook.close()

def outicode(data):
    file = 'Method6/指标-编码对应集合.xlsx'
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})
    worksheet1 = workbook.add_worksheet('Logistic')

    for col_num, value in enumerate(data.columns.values):
        worksheet1.write(0, col_num + 1, value)

    for row_num, value in enumerate(data.index):
        worksheet1.write(row_num + 1, 0, value)

    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            worksheet1.write(i + 1, j + 1, data.iloc[i, j])

    workbook.close()

def data_split(df, train_pct):
    # 返回df_train与df_test
    train = math.floor(len(df) * train_pct)
    df_train = df.iloc[:train]
    df_test = df.iloc[train:]
    return df_train, df_test


def RunTest(p1,p3,p5):
    # -------------------------------------------------控制面板,调整五个参数
    p1 = p1  # 训练集比例
    p3 = p3  # 选择与趋势和滤波相关性前p3的变量
    p5 = p5  # 数据文件名称

    # read data & set index
    Trend = pd.read_excel(p5, sheet_name='趋势', header=0, index_col=0)
    Fluc = pd.read_excel(p5, sheet_name='波动', header=0, index_col=0)
    df_rate = pd.read_excel(p5, sheet_name='利率', header=0, index_col=0)
    load_data = pd.concat([df_rate,Trend], axis=1)
    load_data = pd.concat([load_data,Fluc], axis=1)
    index = load_data.index

    # split into two sets
    df_rate = load_data.loc[:, ['rate']]
    df_indep = load_data.iloc[:, 1:load_data.shape[0]-1]

    # 相关性排序并生成备选指标
    num = p3  # 选择相关性前几的变量
    unm_list = list(range(1, num + 1))
    df_data = pd.concat([df_rate, df_indep.shift(1)], axis=1).interpolate().dropna()
    corr_data = abs(df_data.corr())
    data_variables = (corr_data['rate'].sort_values(ascending=False))[1:num + 1]

    # 导出相关性分析结果和前几备选指标
    data_variables = data_variables.to_frame()
    data_variables.columns = ['相关性']
    data_variables['index'] = unm_list
    outicode(data_variables)

    # 从上一步导出的文件读入指标名称并提取对应指标
    data = pd.read_excel('Method6/指标-编码对应集合.xlsx', sheet_name='Logistic', header=0, index_col=2)
    data = data['Unnamed: 0'].tolist()
    data = df_indep.loc[:, data]
    data.columns = unm_list

    # generate binary tags
    y_lst = []
    for c in range(1, df_rate.shape[0]):
        if df_rate.iloc[c, 0] > df_rate.iloc[c - 1, 0]:
            y_lst.append(1)
        else:
            y_lst.append(0)

    # generate binary tags
    df_x = data.iloc[:-1]
    x_lst = df_x.values.tolist()
    index = index[1:len(index)]
    # generate regression dataset
    y = pd.DataFrame(y_lst, index=index, columns=['tag'])
    x = pd.DataFrame(x_lst, index=index, columns=unm_list)
    y = y.iloc[1:len(y)]
    x = x.shift(1)
    x = x.iloc[1:len(x)].interpolate()

    # -------------------------------------------------Run logistic regression
    # run regression
    lr = LogisticRegression()
    train_pct = p1

    y_train, y_test = data_split(y, train_pct)
    x_train, x_test = data_split(x, train_pct)

    test_size = len(y_test)

    pred_dict = {'date': [], 'pred': []}
    result = pd.DataFrame()

    # 一次预测
    predict_index = y_test.index

    lr.fit(x_train, y_train)
    w = lr.coef_
    b = lr.intercept_
    predict_value = pd.DataFrame(lr.predict(x_test), index=predict_index, columns=['pred_y'])
    predict_proba = pd.DataFrame(lr.predict_proba(x_test), index=predict_index, columns=['0', '1'])

    result = pd.concat([y, predict_value], axis=1)

    # Calculate the win rate
    win = 0
    lose = 0
    win_lst = []
    i = 1 # 胜率对比 t + i 日

    for c in range(y_train.shape[0], result.shape[0]):
        if result.iloc[c, 0] == result.iloc[c, 1]:
            win += 1
            win_lst.append(1)
        else:
            lose += 1
            win_lst.append(0)

    win_rate = win / (win + lose) * 100

    df6 = pd.DataFrame([win,lose,win_rate],index=['win','lose','win rate'],columns=['Logistic'])
    output(data_variables, result, df6)

    return df6
