# -------------------------------------------------Libraries
import pandas as pd
import xlsxwriter
from sklearn.linear_model import LogisticRegression
import toad
import math


# -------------------------------------------------Functions
def output(data_variables, df8, result):
    file = 'Method8/Results.xlsx'
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})
    worksheet1 = workbook.add_worksheet('Notes')
    worksheet2 = workbook.add_worksheet('Results')
    worksheet3 = workbook.add_worksheet('Details')
    date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})

    for col_num, value in enumerate(data_variables.columns.values):
        worksheet1.write(0, col_num + 1, value)

    for row_num, value in enumerate(data_variables.index):
        worksheet1.write(row_num + 1, 0, value)

    for i in range(data_variables.shape[0]):
        for j in range(data_variables.shape[1]):
            worksheet1.write(i + 1, j + 1, data_variables.iloc[i, j])

    for col_num, value in enumerate(result.columns.values):
        worksheet2.write(0, col_num + 1, value)

    for row_num, value in enumerate(result.index):
        worksheet2.write(row_num + 1, 0, value)

    for i in range(result.shape[0]):
        for j in range(result.shape[1]):
            worksheet2.write(i + 1, j + 1, result.iloc[i, j])

    for col_num, value in enumerate(df8.columns.values):
        worksheet3.write(0, col_num + 1, value)

    for row_num, value in enumerate(df8.index):
        worksheet3.write(row_num + 1, 0, value, date_format)

    for i in range(df8.shape[0]):
        for j in range(df8.shape[1]):
            worksheet3.write(i + 1, j + 1, df8.iloc[i, j])
            
    workbook.close()
            
def outicode(data):
    file = 'Method8/指标-编码对应集合.xlsx'
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})
    worksheet1 = workbook.add_worksheet('Logistic')

    for col_num, value in enumerate(data.columns.values):
        worksheet1.write(0, col_num + 1, value)

    for row_num, value in enumerate(data.index):
        worksheet1.write(row_num + 1, 0, value)

    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            worksheet1.write(i + 1, j + 1, data.iloc[i, j])

    workbook.close()
    
def outwoe(woe_data):
    file = 'Method8/指标分箱与woe值信息.xlsx'
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})
    worksheet1 = workbook.add_worksheet('分箱')

    worksheet1.write(0, 1, '分箱')
    worksheet1.write(0, 2, 'woe')
    
    row = 1
    
    for key, value in woe_data.items():
        for sub_key, sub_value in value.items():
            worksheet1.write(row, 0, key)
            worksheet1.write(row, 1, sub_key)
            worksheet1.write(row, 2, sub_value)
            row += 1
    
    workbook.close()
    
def data_split(df, train_pct):
    # 返回df_train与df_test
    train = math.floor(len(df) * train_pct)
    df_train = df.iloc[:train]
    df_test = df.iloc[train:]
    return df_train, df_test    
    
    
def RunTest(p1,p3,p5):
    # -------------------------------------------------控制面板,调整五个参数
    p1 = p1  # 训练集比例
    p3 = p3  # 选择与趋势和滤波相关性前p3的变量
    p5 = p5  # 数据文件名称

    # read data & set index
    Trend = pd.read_excel(p5, sheet_name='趋势', header=0, index_col=0)
    Fluc = pd.read_excel(p5, sheet_name='波动', header=0, index_col=0)
    df_rate = pd.read_excel(p5, sheet_name='利率', header=0, index_col=0)
    load_data = pd.concat([df_rate,Trend], axis=1)
    load_data = pd.concat([load_data,Fluc], axis=1)

    # split into two sets
    df_rate = load_data.loc[:, ['rate']]
    df_indep = load_data.iloc[:, 1:load_data.shape[1]]


    # generate binary tags
    # generate regression dataset
    df_data = pd.concat([df_rate, df_indep.shift(1)], axis=1).interpolate()
    df_data['rate'] = ((df_rate['rate'] - df_rate['rate'].shift(1)).dropna() > 0).astype(int)
    df_data = df_data.dropna()
    
    # 分割训练集与测试集
    df_train, df_test = data_split(df_data, p1)
    # 建立决策树分箱模型
    bining_model = toad.transform.Combiner()
    bining_model.fit(df_train, y = 'rate', method = 'dt', min_samples = 0.05)
    # 存储训练集分箱后结果
    df_binning_train = bining_model.transform(df_train, labels = True)
    # 计算IV值用于变量筛选
    df_iv = toad.quality(df_binning_train, target='rate', iv_only=True)
    df_iv = df_iv.loc[:, ['iv', 'unique']]
    df_iv['index'] = range(1, len(df_iv) + 1)
    # 导出IV值
    outicode(df_iv.iloc[:p3, :])
    
    # 选取前p3大变量进行建模
    variable_names = ['rate'] + list(df_iv.head(p3).index)
    df_test_reduced = df_test.loc[:, variable_names]
    df_binning_test_reduced = bining_model.transform(df_test_reduced, labels = True)
    df_train_reduced = df_train.loc[:, variable_names]
    df_binning_train_reduced = bining_model.transform(df_train_reduced, labels = True)
    
    # 转化woe值
    woe_transer = toad.transform.WOETransformer()
    woe_transer.fit(df_binning_train_reduced, y = 'rate')
    df_woe_test_reduced = woe_transer.transform(df_binning_test_reduced)
    # df_woe_test_reduced = bining_model.transform(df_test_reduced)
    
    # -------------------------------------------------Run logistic regression
    # run regression
    lr_reduced = LogisticRegression(max_iter=500)
    lr_reduced.fit(X = df_woe_test_reduced.iloc[:, 1:], y = df_woe_test_reduced.iloc[:, 0])

    result = pd.DataFrame()

    # 一次预测
    predict_index = df_woe_test_reduced.index
    w = lr_reduced.coef_
    b = lr_reduced.intercept_
    predict_value = pd.DataFrame(lr_reduced.predict(df_woe_test_reduced.iloc[:, 1:]), index=predict_index, columns=['pred_y'])
    predict_proba = pd.DataFrame(lr_reduced.predict_proba(df_woe_test_reduced.iloc[:, 1:]), index=predict_index, columns=['0', '1'])

    result = pd.concat([df_woe_test_reduced.iloc[:, 0], predict_value], axis=1)

    # Calculate the win rate
    win = 0
    lose = 0
    win_lst = []

    for c in result.values:
        if c[0] == c[1]:
            win += 1
            win_lst.append(1)
        else:
            lose += 1
            win_lst.append(0)

    win_rate = win / (win + lose) * 100

    df8 = pd.DataFrame([win,lose,win_rate],index=['win','lose','win rate'],columns=['Logistic'])
    output(df_iv, result, df8)
    
    # 存储分箱结果
    woe_dict = woe_transer.export()
    outwoe(woe_dict)
    
    return df8

    
    
    
    
    
    
    
    