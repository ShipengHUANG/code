# -------------------------------------------------Libraries
import numpy as np
import pandas as pd
import math
import xlsxwriter
import time
import warnings
from sklearn.model_selection import KFold
from statsmodels.tsa.api import VAR
from itertools import combinations
warnings.filterwarnings('ignore')

# -------------------------------------------------Functions
def output(a, b, data, details):
    file = 'Method1/Results.xlsx'
    details = details.replace(np.NaN, '')
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})
    worksheet1 = workbook.add_worksheet('Notes')
    worksheet2 = workbook.add_worksheet('Results')
    worksheet3 = workbook.add_worksheet('Details')
    date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})

    worksheet1.write(0, 0, '趋势变量编码')
    for col_num, value in enumerate(a.columns.values):
        worksheet1.write(0, col_num + 1, value)

    for row_num, value in enumerate(a.index):
        worksheet1.write(row_num + 1, 0, value)

    for i in range(a.shape[0]):
        for j in range(a.shape[1]):
            worksheet1.write(i + 1, j + 1, a.iloc[i, j])

    worksheet2.write(0, 5, '波动变量编码')
    for col_num, value in enumerate(b.columns.values):
        worksheet1.write(0, col_num + 6, value)

    for row_num, value in enumerate(b.index):
        worksheet1.write(row_num + 1, 5, value)

    for i in range(b.shape[0]):
        for j in range(b.shape[1]):
            worksheet1.write(i + 1, j + 6, b.iloc[i, j])

    for col_num, value in enumerate(data.columns.values):
        worksheet2.write(0, col_num + 1, value)

    for row_num, value in enumerate(data.index):
        worksheet2.write(row_num + 1, 0, value)

    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            worksheet2.write(i + 1, j + 1, data.iloc[i, j])

    for col_num, value in enumerate(details.columns.values):
        worksheet3.write(0, col_num + 1, value)

    for row_num, value in enumerate(details.index):
        worksheet3.write(row_num + 1, 0, value, date_format)

    for i in range(details.shape[0]):
        for j in range(details.shape[1]):
            worksheet3.write(i + 1, j + 1, details.iloc[i, j])

    workbook.close()


def outicode(data, data2):
    file = 'Method1/指标-编码对应集合.xlsx'
    workbook = xlsxwriter.Workbook(file, {'nan_inf_to_errors': True})
    worksheet1 = workbook.add_worksheet('趋势')
    worksheet2 = workbook.add_worksheet('波动')

    for col_num, value in enumerate(data.columns.values):
        worksheet1.write(0, col_num + 1, value)

    for row_num, value in enumerate(data.index):
        worksheet1.write(row_num + 1, 0, value)

    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            worksheet1.write(i + 1, j + 1, data.iloc[i, j])

    for col_num, value in enumerate(data2.columns.values):
        worksheet2.write(0, col_num + 1, value)

    for row_num, value in enumerate(data2.index):
        worksheet2.write(row_num + 1, 0, value)

    for i in range(data2.shape[0]):
        for j in range(data2.shape[1]):
            worksheet2.write(i + 1, j + 1, data2.iloc[i, j])

    workbook.close()


def KalmanFilter(z, RQ, n_iter=20):
    # 这里是假设A=1，H=1的情况
    # intial parameters

    sz = (n_iter,)  # size of array

    # process variance
    Q = 0.0001

    # allocate space for arrays
    xhat = np.zeros(sz)  # a posteri estimate of x
    P = np.zeros(sz)  # a posteri error estimate
    xhatminus = np.zeros(sz)  # a priori estimate of x
    Pminus = np.zeros(sz)  # a priori error estimate
    K = np.zeros(sz)  # gain or blending factor

    # estimate of measurement variance, change to see effect
    R = RQ * Q

    # intial guesses
    xhat[0] = 0.0
    P[0] = 1.0
    A = 1
    H = 1

    for k in range(1, n_iter):
        # time update
        xhatminus[k] = A * xhat[k - 1]  # X(k|k-1) = AX(k-1|k-1) + BU(k) + W(k),A=1,BU(k) = 0
        Pminus[k] = A * P[k - 1] + Q  # P(k|k-1) = AP(k-1|k-1)A' + Q(k) ,A=1

        # measurement update
        K[k] = Pminus[k] / (Pminus[k] + R)  # Kg(k)=P(k|k-1)H'/[HP(k|k-1)H' + R],H=1
        xhat[k] = xhatminus[k] + K[k] * (z[k] - H * xhatminus[k])  # X(k|k) = X(k|k-1) + Kg(k)[Z(k) - HX(k|k-1)], H=1
        P[k] = (1 - K[k] * H) * Pminus[k]  # P(k|k) = (1 - Kg(k)H)P(k|k-1), H=1
    return xhat


def Split_Sets_10_Fold(total_fold, df):
    # total_fold: 后续设定10折 data：需要划分的数据
    # train_index,test_index用来存储train和test的index（索引）
    train_index = []
    test_index = []
    kf = KFold(n_splits=total_fold, shuffle=False)
    # 设置shuffle设置为ture打乱顺序再分配
    for train_i, test_i in kf.split(df):
        train_index.append(train_i)
        test_index.append(test_i)
    # 返回训练集，测试集
    return train_index, test_index


def data_split(df, train_pct):
    # 返回df_train与df_test
    train = math.floor(len(df) * train_pct)
    df_train = df.iloc[:train]
    df_test = df.iloc[train:]
    return df_train, df_test

def RunTest(p1,p2,p3,p4,p5):
    # -------------------------------------------------控制面板,调整五个参数
    p1 = p1  # 训练集比例
    p2 = p2  # 测试的卡尔曼滤波参数，全集为 [10000, 5000, 1000, 500, 100, 50, 10, 5, 1, 0.50, 0.10, 0.05]
    p3 = p3  # 选择与趋势和滤波相关性前p3的变量
    p4 = p4  # 应选出的指标数
    p5 = p5  # 数据文件名称
    # -------------------------------------------------Loading data
    # 变量设定
    train_pct = p1
    kalman_index = p2
    v = []
    vv = []
    y = []
    z = []
    zz = []
    zzz = []
    df = pd.DataFrame()
    details = pd.DataFrame()
    set = 0
    rate_columns = ['rate']
    a = pd.DataFrame()
    b = pd.DataFrame()

    # 数据读取
    Trend = pd.read_excel(p5, sheet_name='趋势', header=0, index_col=0)
    Fluc = pd.read_excel(p5, sheet_name='波动', header=0, index_col=0)
    df_rate = pd.read_excel(p5, sheet_name='利率', header=0, index_col=0)
    trend_ind = pd.DataFrame(Trend)
    fluc_ind = pd.DataFrame(Fluc)

    # 卡尔曼滤波
    for ii in range(0, len(kalman_index)):
        trend = KalmanFilter(df_rate['rate'], kalman_index[ii], n_iter=len(df_rate))[1:]
        fluc = df_rate['rate'].tolist()[1:] - trend
        df_trend = pd.DataFrame(trend.transpose(), columns=['trend'], index=df_rate.index[1:])
        df_fluc = pd.DataFrame(fluc.transpose(), columns=['fluc'], index=df_rate.index[1:])

        # 相关性排序并生成备选指标
        num = p3  # 选择相关性前几的变量
        unm_list = list(range(1, num + 1))
        df_trend = pd.concat([df_trend, trend_ind.shift(1)], axis=1).interpolate().dropna()
        corr_trend = abs(df_trend.corr())
        df_fluc = pd.concat([df_fluc, fluc_ind.shift(1)], axis=1).interpolate().dropna()
        corr_fluc = abs(df_fluc.corr())
        trend_variables = (corr_trend['trend'].sort_values(ascending=False))[1:num + 1]
        fluc_variables = (corr_fluc['fluc'].sort_values(ascending=False))[1:num + 1]

        # 导出相关性分析结果和前几备选指标
        trend_variables = trend_variables.to_frame()
        trend_variables.columns = ['相关性']
        trend_variables['RQ'] = kalman_index[ii]
        trend_variables['index'] = unm_list
        fluc_variables = fluc_variables.to_frame()
        fluc_variables.columns = ['相关性']
        fluc_variables['RQ'] = kalman_index[ii]
        fluc_variables['index'] = unm_list
        outicode(trend_variables, fluc_variables)
        a = pd.concat([a, trend_variables], axis=0)
        b = pd.concat([b, fluc_variables], axis=0)

        # 从上一步导出的文件读入指标名称并提取对应指标
        trend = pd.read_excel('Method1/指标-编码对应集合.xlsx', sheet_name='趋势', header=0, index_col=3)
        fluc = pd.read_excel('Method1/指标-编码对应集合.xlsx', sheet_name='波动', header=0, index_col=3)
        trend = trend['Unnamed: 0'].tolist()
        fluc = fluc['Unnamed: 0'].tolist()
        trend = trend_ind.loc[:, trend]
        fluc = fluc_ind.loc[:, fluc]
        trend.columns = unm_list
        fluc.columns = unm_list

        # 对趋势和波动的待选指标分别进行排列组合
        c = p3  # 趋势待选指标总数
        d = p4  # 趋势应选出的指标数
        value = list(combinations([i for i in range(1, c + 1)], d))
        key = [i for i in range(1, len(value) + 1)]
        comb = dict(zip(key, value))
        combnum = len(value)
        w = []
        x = []
        wint1 = []
        wint2 = []
        print(value)
        # 对排列组合进行循环遍历回归
        for key in comb:
            select1 = list(comb[key])

            var_trend_all = pd.concat([df_trend.loc[:, ['trend']], trend.loc[:, select1]], axis=1).interpolate().dropna()
            var_fluc_all = pd.concat([df_fluc.loc[:, ['fluc']], fluc.loc[:, select1]], axis=1).interpolate().dropna()
            var_trend, test_trend = data_split(var_trend_all, p1)
            var_fluc, test_fluc = data_split(var_fluc_all, p1)
            w.append(kalman_index[ii])
            x.append(select1)

            # -------------------------------------------------VAR Forecasting
            # 8 folds test
            total_fold = 8
            total_win_rate = 0
            fold_calc = 0
            [trend_train_index, trend_test_index] = Split_Sets_10_Fold(total_fold, var_trend)
            print("Method1: 滤波参数第", ii + 1, "/", len(kalman_index), "个；开始趋势项的第", key, "/", combnum, "个变量组合测试")

            for trend_train_ind, trend_test_ind in zip(trend_train_index, trend_test_index):
                fold_calc += 1
                trend_train = var_trend.iloc[trend_train_ind, :]  # 得到训练数据
                trend_test = var_trend.iloc[trend_test_ind, :]  # 得到测试数据
                trend_size = len(trend_test)

                win_trend = 0
                lose_trend = 0

                # Rolling VAR Forecast for trends
                for i in range(trend_size - 4):
                    training_trend = trend_train

                    model = VAR(training_trend)
                    model_fit = model.fit(3)
                    trend_params = model_fit.params
                    trend_history = trend_test.iloc[i:i + 3, :]
                    yhat = trend_params.iloc[0, 0] + \
                           trend_params.iloc[1, 0] * trend_history.iloc[2, 0] + \
                           trend_params.iloc[2, 0] * trend_history.iloc[2, 1] + \
                           trend_params.iloc[3, 0] * trend_history.iloc[2, 2] + \
                           trend_params.iloc[4, 0] * trend_history.iloc[2, 3] + \
                           trend_params.iloc[5, 0] * trend_history.iloc[2, 4] + \
                           trend_params.iloc[6, 0] * trend_history.iloc[2, 5] + \
                           trend_params.iloc[7, 0] * trend_history.iloc[1, 0] + \
                           trend_params.iloc[8, 0] * trend_history.iloc[1, 1] + \
                           trend_params.iloc[9, 0] * trend_history.iloc[1, 2] + \
                           trend_params.iloc[10, 0] * trend_history.iloc[1, 3] + \
                           trend_params.iloc[11, 0] * trend_history.iloc[1, 4] + \
                           trend_params.iloc[12, 0] * trend_history.iloc[1, 5] + \
                           trend_params.iloc[13, 0] * trend_history.iloc[0, 0] + \
                           trend_params.iloc[14, 0] * trend_history.iloc[0, 1] + \
                           trend_params.iloc[15, 0] * trend_history.iloc[0, 2] + \
                           trend_params.iloc[16, 0] * trend_history.iloc[0, 3] + \
                           trend_params.iloc[17, 0] * trend_history.iloc[0, 4] + \
                           trend_params.iloc[18, 0] * trend_history.iloc[0, 5]

                    if (yhat - trend_test.iloc[i + 2, 0]) * (trend_test.iloc[i + 3, 0] - trend_test.iloc[i + 2, 0]) >= 0:
                        win_trend += 1
                    else:
                        lose_trend += 1

                win_rate_trend = win_trend / (win_trend + lose_trend) * 100
                # print("第", fold_calc, "折胜率", win_rate_trend, "%")
                total_win_rate = total_win_rate + win_rate_trend

            wint1.append(total_win_rate / 8)
            # print("第", key, "变量组合平均胜利", total_win_rate/8, "%")

            total_fold = 10
            total_win_rate = 0
            fold_calc = 0
            [fluc_train_index, fluc_test_index] = Split_Sets_10_Fold(total_fold, var_fluc)
            print("Method1: 滤波参数第", ii + 1, "/", len(kalman_index), "个；开始波动项的第", key, "/", combnum, "个变量组合测试")

            for fluc_train_ind, fluc_test_ind in zip(fluc_train_index, fluc_test_index):
                fold_calc += 1
                fluc_train = var_fluc.iloc[fluc_train_ind, :]  # 得到训练数据
                fluc_test = var_fluc.iloc[fluc_test_ind, :]  # 得到测试数据
                fluc_size = len(fluc_test)

                win_fluc = 0
                lose_fluc = 0

                # Rolling VAR Forecast for trends
                for i in range(fluc_size - 4):
                    training_fluc = fluc_train

                    model = VAR(training_fluc)
                    model_fit = model.fit(3)
                    fluc_params = model_fit.params
                    fluc_history = fluc_test.iloc[i:i + 3, :]
                    yhat = fluc_params.iloc[0, 0] + \
                           fluc_params.iloc[1, 0] * fluc_history.iloc[2, 0] + \
                           fluc_params.iloc[2, 0] * fluc_history.iloc[2, 1] + \
                           fluc_params.iloc[3, 0] * fluc_history.iloc[2, 2] + \
                           fluc_params.iloc[4, 0] * fluc_history.iloc[2, 3] + \
                           fluc_params.iloc[5, 0] * fluc_history.iloc[2, 4] + \
                           fluc_params.iloc[6, 0] * fluc_history.iloc[2, 5] + \
                           fluc_params.iloc[7, 0] * fluc_history.iloc[1, 0] + \
                           fluc_params.iloc[8, 0] * fluc_history.iloc[1, 1] + \
                           fluc_params.iloc[9, 0] * fluc_history.iloc[1, 2] + \
                           fluc_params.iloc[10, 0] * fluc_history.iloc[1, 3] + \
                           fluc_params.iloc[11, 0] * fluc_history.iloc[1, 4] + \
                           fluc_params.iloc[12, 0] * fluc_history.iloc[1, 5] + \
                           fluc_params.iloc[13, 0] * fluc_history.iloc[0, 0] + \
                           fluc_params.iloc[14, 0] * fluc_history.iloc[0, 1] + \
                           fluc_params.iloc[15, 0] * fluc_history.iloc[0, 2] + \
                           fluc_params.iloc[16, 0] * fluc_history.iloc[0, 3] + \
                           fluc_params.iloc[17, 0] * fluc_history.iloc[0, 4] + \
                           fluc_params.iloc[18, 0] * fluc_history.iloc[0, 5]

                    if (yhat - fluc_test.iloc[i + 2, 0]) * (fluc_test.iloc[i + 3, 0] - fluc_test.iloc[i + 2, 0]) >= 0:
                        win_fluc += 1
                    else:
                        lose_fluc += 1

                win_rate_fluc = win_fluc / (win_fluc + lose_fluc) * 100
                # print("第", fold_calc, "折胜率", win_rate_fluc, "%")
                total_win_rate = total_win_rate + win_rate_fluc

            wint2.append(total_win_rate / 8)
            # print("第", key, "变量组合平均胜利", total_win_rate/8, "%")

        # Output the results
        res1 = pd.concat([pd.DataFrame(x), pd.DataFrame(w, columns=['R/Q'])], axis=1)
        res1 = pd.concat([res1, pd.DataFrame(wint1, columns=['趋势平均验证胜率'])], axis=1)
        table1 = res1.sort_values(by='趋势平均验证胜率', ascending=False)
        table1 = table1.reset_index(drop=True)
        res2 = pd.concat([pd.DataFrame(x), pd.DataFrame(w, columns=['R/Q'])], axis=1)
        res2 = pd.concat([res2, pd.DataFrame(wint2, columns=['波动平均验证胜率'])], axis=1)
        table2 = res2.sort_values(by='波动平均验证胜率', ascending=False)
        table2 = table2.reset_index(drop=True)
        table = pd.concat([table1, table2], axis=1)
        list_t = list(table1.iloc[0, 0:p4])
        list_f = list(table2.iloc[0, 0:p4])

        # forecasting test
        trend_fore = pd.concat([df_trend.loc[:, ['trend']], trend.loc[:, list_t]], axis=1).interpolate().dropna()
        fluc_fore = pd.concat([df_fluc.loc[:, ['fluc']], fluc.loc[:, list_f]], axis=1).interpolate().dropna()

        # set dictionary & sample size
        pred_dict_trend = {'date': [], 'pred_trend': []}
        pred_dict_fluc = {'date': [], 'pred_fluc': []}

        trend_train, trend_test = data_split(trend_fore, p1)
        fluc_train, fluc_test = data_split(fluc_fore, p1)

        trend_size = len(trend_test)
        fluc_size = len(fluc_test)
        d3 = []
        d4 = []

        # Rolling VAR Forecast for trends
        for i in range(trend_size):
            training_trend = trend_fore[:(-trend_size + i)]

            model = VAR(training_trend)
            model_fit = model.fit(3)
            model_results = model_fit.forecast_interval(model_fit.endog, steps=1)
            pred_date = trend_fore.index[len(trend_train) + i]
            pred_dict_trend['date'].append(pred_date)
            pred_dict_trend['pred_trend'].append(model_results[0][0][0])
            # print('趋势项第', i + 1, '/', trend_size, '天预测')

        trend_pred = pd.DataFrame(pred_dict_trend)
        trend_pred.set_index(["date"], inplace=True)
        var_trend = pd.concat([df_trend.loc[:, 'trend'], trend_pred], axis=1)

        # Rolling VAR Forecast for fluctuations
        for i in range(fluc_size):
            training_fluc = fluc_fore[:(-fluc_size + i)]

            model = VAR(training_fluc)
            model_fit = model.fit(3)
            model_results = model_fit.forecast_interval(model_fit.endog, steps=1)

            pred_date = fluc_fore.index[len(fluc_train) + i]
            pred_dict_fluc['date'].append(pred_date)
            pred_dict_fluc['pred_fluc'].append(model_results[0][0][0])
            # print('波动项第', i + 1, '/', fluc_size, '天预测')

        trend_fluc = pd.DataFrame(pred_dict_fluc)
        trend_fluc.set_index(["date"], inplace=True)
        var_fluc = pd.concat([df_fluc.loc[:, 'fluc'], trend_fluc], axis=1)

        # -------------------------------------------------Get the results
        # Calculate the forecasted bond yields
        df1 = pd.concat([var_trend, var_fluc], axis=1)
        df2 = pd.concat([df1, df_rate], axis=1)
        df2["pre_rate"] = df1[["pred_fluc", "pred_trend"]].apply(lambda x: x["pred_fluc"] + x["pred_trend"], axis=1)

        # Calculate the win rate
        win1 = 0
        lose1 = 0
        win_lst1 = []
        win2 = 0
        lose2 = 0
        win_lst2 = []
        win3 = 0
        lose3 = 0
        win_lst3 = []
        i = 1  # 胜率对比 t + i 日

        for c in range(fluc_train.shape[0] + 2, df2.shape[0] - i):
            if (df2.iloc[c, 1] - df2.iloc[c - i, 0]) * (df2.iloc[c, 0] - df2.iloc[c - i, 0]) > 0:
                win1 += 1
                win_lst1.append(1)
            else:
                lose1 += 1
                win_lst1.append(0)

        for c in range(fluc_train.shape[0] + 2, df2.shape[0] - i):
            if (df2.iloc[c, 3] - df2.iloc[c - i, 2]) * (df2.iloc[c, 2] - df2.iloc[c - i, 2]) > 0:
                win2 += 1
                win_lst2.append(1)
            else:
                lose2 += 1
                win_lst2.append(0)

        for c in range(fluc_train.shape[0] + 2, df2.shape[0] - i):
            if (df2.iloc[c, 5] - df2.iloc[c - i, 4]) * (df2.iloc[c, 4] - df2.iloc[c - i, 4]) > 0:
                win3 += 1
                win_lst3.append(1)
            else:
                lose3 += 1
                win_lst3.append(0)

        win_rate1 = win1 / (win1 + lose1) * 100
        win_rate2 = win2 / (win2 + lose2) * 100
        win_rate3 = win3 / (win3 + lose3) * 100

        firsttable = table.loc[[0], :]
        firsttable.columns = ['x1', 'x2', 'x3', 'x4', 'x5', 'R/Q', '趋势平均验证胜率', 'x1', 'x2', 'x3', 'x4', 'x5', 'R/Q',
                              '波动平均验证胜率']
        firsttable["趋势序列预测胜率"] = win_rate1
        firsttable["波动序列预测胜率"] = win_rate2
        firsttable["合成预测利率胜率"] = win_rate3
        df = pd.concat([df, firsttable], axis=0)
        df = df.sort_values(by='合成预测利率胜率', ascending=False)
        df = df.reset_index(drop=True)
        details = pd.concat([details, df2], axis=1)

    output(a, b, df, details)

    return df
