########1#########2#########3#########4#########5#########6#########7##########
#                                                                             #
#   2. Nehru Method2 Models (01/02/2023)                                      #
#                                                                             # 
#   This program estimates initial capital stock by the second approach from  #
#   Nehru's paper.  The model iterates the process 20 times to make the       #
#   result converge to a specific level.                                      #
#                                                                             #
#########1#########2#########3#########4#########5#########6#########7#########

#   load packages

    library(readxl)
    library(plm)
    library(stargazer)
    library(lmtest)
    library(openxlsx)

#   load database, set the variables
    
    data_all <- read_excel("MYMETHOD3_var.xlsx")
    data_all <- data.frame(data_all)
    data_all <- data_all[,1:21]
    data_test <- data_all[which(data_all$Year>=2000),]
    data_test$LOGGDPpc <- log(data_test$Y/data_test$L)
    data_test$kcor <- log(data_test$Method1/data_test$L)
    data_test$klor <- log(data_test$Method2/data_test$L)
    data_test$knlr <- log(data_test$Method3/data_test$L)
    data_test$khar <- log(data_test$Method4/data_test$L)
    data_test$kcor_con <- log(data_test$Method1_con/data_test$L)
    data_test$klor_con <- log(data_test$Method2_con/data_test$L)
    data_test$knlr_con <- log(data_test$Method3_con/data_test$L)
    data_test$khar_con <- log(data_test$Method4_con/data_test$L)

#   STEP 1: Set the models

    M1 <- LOGGDPpc ~ kcor
    M2 <- LOGGDPpc ~ klor
    M3 <- LOGGDPpc ~ knlr
    M4 <- LOGGDPpc ~ khar
    
    M5 <- LOGGDPpc ~ kcor_con
    M6 <- LOGGDPpc ~ klor_con
    M7 <- LOGGDPpc ~ knlr_con
    M8 <- LOGGDPpc ~ khar_con
    
#   Step 2: Estimate the models using all countries
    
    model1_all <- lm(formula = M1, data = data_test)
    model2_all <- lm(formula = M2, data = data_test)
    model3_all <- lm(formula = M3, data = data_test)
    model4_all <- lm(formula = M4, data = data_test)
    model5_all <- lm(formula = M5, data = data_test)
    model6_all <- lm(formula = M6, data = data_test)
    model7_all <- lm(formula = M7, data = data_test)
    model8_all <- lm(formula = M8, data = data_test)
    
    model1_all <- plm(formula = M1, data = data_test, 
                      index = c("CName", "Year"),
                      model = "random", effect = "twoways")
    model2_all <- plm(formula = M2, data = data_test, 
                      index = c("CName", "Year"),
                      model = "random", effect = "twoways")
    model3_all <- plm(formula = M3, data = data_test, 
                      index = c("CName", "Year"),
                      model = "random", effect = "twoways")
    model4_all <- plm(formula = M4, data = data_test, 
                      index = c("CName", "Year"),
                      model = "random", effect = "twoways")
    model5_all <- plm(formula = M5, data = data_test, 
                      index = c("CName", "Year"),
                      model = "random", effect = "twoways")
    model6_all <- plm(formula = M6, data = data_test, 
                      index = c("CName", "Year"),
                      model = "random", effect = "twoways")
    model7_all <- plm(formula = M7, data = data_test, 
                      index = c("CName", "Year"),
                      model = "random", effect = "twoways")
    model8_all <- plm(formula = M8, data = data_test, 
                      index = c("CName", "Year"),
                      model = "random", effect = "twoways")
    
    a <- stargazer(model1_all, model2_all, model3_all, model4_all, type = "text", align=TRUE, out = "1.html") 
    b <- stargazer(model5_all, model6_all, model7_all, model8_all, type = "text", align=TRUE, out = "2.html") 
    
    

    
    