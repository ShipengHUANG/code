########1#########2#########3#########4#########5#########6#########7##########
#                                                                             #
#   2. Nehru Method2 Models (01/02/2023)                                      #
#                                                                             # 
#   This program estimates initial capital stock by the second approach from  #
#   Nehru's paper.  The model iterates the process 20 times to make the       #
#   result converge to a specific level.                                      #
#                                                                             #
#########1#########2#########3#########4#########5#########6#########7#########

#   load packages

    library(readxl)
    library(plm)
    library(stargazer)
    library(lmtest)
    library(openxlsx)

#   load database, set the variables

    
    data_all <- read_excel("MYMETHODCON.xlsx") #'MYMETHOD.xlsx' or 'MYMETHODCON.xlsx'
    data_all <- data.frame(data_all)
    data_all <- data_all[,1:22]
    result <- data_all
#   STEP 1: Set the models

    
    #   Step 2: Estimate the models using all countries
    
    clist <- list('ABW','AFG','AGO','AIA','ALB','AND','ARE','ARG','ATG','ATG','AUS','AUT','BDI','BEL','BEN','BFA','BGD','BGR','BHR','BHS','BLZ','BMU','BOL','BRA','BRB','BRN','BTN','BWA','CAF','CAN','CHE','CHL','CHN','CIV','CMR','COD','COG','COL','COM','CPV','CRI','CUB','CYM','CYP','DEU','DJI','DMA','DNK','DOM','DZA','ECU','EGY','ESP','ETH','FIN','FJI','FRA','FSM','GAB','GBR','GHA','GIN','GMB','GNB','GNQ','GRC','GRD','GRL','GTM','GUY','HKG','HND','HTI','HUN','IDN','IND','IRL','IRN','IRQ','ISL','ISR','ITA','JAM','JOR','JPN','KEN','KHM','KIR','KNA','KOR','KWT','LAO','LBN','LBR','LBY','LCA','LIE','LKA','LSO','LUX','MAC','MAR','MCO','MDG','MDV','MEX','MHL','MLI','MLT','MMR','MNG','MOZ','MRT','MSR','MUS','MWI','MYS','NAM','NCL','NER','NGA','NIC','NLD','NOR','NPL','NRU','NZL','OMN','PAK','PAN','PER','PHL','PLW','PNG','POL','PRI','PRT','PRY','PSE','PYF','QAT','ROU','RWA','SAU','SDN','SEN','SGP','SLB','SLE','SLV','SMR','SOM','STP','SUR','SWE','SWZ','SYC','SYR','TCA','TCD','TGO','THA','TON','TTO','TUN','TUR','TUV','TWN','TZA','UGA','URY','USA','VCT','VEN','VGB','VNM','VUT','WSM','ZAF','ZMB','ZWE')

    for (n in list(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50)){
      for (c in clist){
        for (s in list(0.01,0.05,0.1,0.5,1)){
          data_test <- data_all[which(data_all$CCode==c),]
          data_test <- data_test[complete.cases(data_test), ]
          data_test$logY <- log(data_test$Y)
          data_test$logL <- log(data_test$L)
          
          skip_to_next <- FALSE
          tryCatch({model1_all <- nls(logY ~ beta1 + beta2*log(abs(beta3*x1 + x2)) + beta4*logL,
                                      data=data_test,
                                      start=c(beta1=5,beta2=5,beta3=s*data_test[n,'Method1'],beta4=5)) #'Method1' or 'Method2_.20' / beta124=555 or 522
          coefs <- coef(model1_all)
          Code <- data_test[1,"CCode"]
          
          
          for (r in 1:nrow(result)){
            if (result[r,"start"]==1 && result[r, 'CCode']==Code){
              result[r,paste('Method3_con_',n,'_',s)] <- abs(coefs[3])
            }
          }
          }, error = function(e) { skip_to_next <<- TRUE})
          if(skip_to_next) { next }   
        }}
    print(n)
    }
    

    for (r in 1:nrow(result)){
      for (c in 23:ncol(result)){
      if (result[r,"start"]==2){
        result[r,c] <- result[r-1,c]*(1 - result[r,"δ"]) + result[r,"I"]
      }}
    }
#   Step 3: Output the result
    
    wb = createWorkbook()
    addWorksheet(wb,"Method3")
    writeData(wb,"Method3", result, startRow=1, rowNames=TRUE)
    saveWorkbook(wb, "MYMETHOD3_con.xlsx")
    
    
    