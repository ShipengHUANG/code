########1#########2#########3#########4#########5#########6#########7##########
#                                                                             #
#   2. Nehru Method2 Models (01/02/2023)                                      #
#                                                                             # 
#   This program estimates initial capital stock by the second approach from  #
#   Nehru's paper.  The model iterates the process 20 times to make the       #
#   result converge to a specific level.                                      #
#                                                                             #
#########1#########2#########3#########4#########5#########6#########7#########

#   load packages

    library(readxl)
    library(plm)
    library(stargazer)
    library(lmtest)
    library(openxlsx)

#   load database, set the variables

    
    data_all <- read_excel("MYMETHOD.xlsx")
    data_all <- data.frame(data_all)

    data_all$logKL <- log(data_all$Method1)/log(data_all$L)
    data_all$logKY <- log(data_all$Method1)/log(data_all$Y)
    data_all$logLY <- log(data_all$L)/log(data_all$Y)
    data_all$con <- 1/log(data_all$Y)

    data_OECD <- subset(data_all, OECD=="OECD")
    data_non  <- subset(data_all, OECD=="non")


#   STEP 1: Set the models

    M21 <- logKY ~ logKL
    M22 <- logKY ~ logKL + con
    M23 <- logKY ~ logLY
    M24 <- logKY ~ logLY + con
    
#   Step 2: Estimate the models using all countries
    
    for (i in 1:20){
    
      data_reg <- data_all[-which(data_all$Year<2015),]
      
      model1_all <- plm(formula = M21, data = data_reg, 
                        index = c("CName", "Year"),
                        model = "random")
      
      model2_all <- plm(formula = M22, data = data_reg, 
                        index = c("CName", "Year"),
                        model = "random")
      
      model3_all <- plm(formula = M23, data = data_reg, 
                        index = c("CName", "Year"),
                        model = "random")
      
      model4_all <- plm(formula = M24, data = data_reg, 
                        index = c("CName", "Year"),
                        model = "random")
      
      stargazer(model1_all, model2_all, model3_all, model4_all, type = "text", align=TRUE) 
  
      
      coefs <- coef(model3_all)
      data_all[paste('Method2_',i)] <- with(data_all, ifelse(start==1, exp((coefs[1]+coefs[2]*log(L)/log(Y))*log(Y)),NA))
  
      for (r in 1:nrow(data_all)) {
        if (data_all[r,"start"]==2){
          data_all[r,paste('Method2_',i)] <- data_all[r-1,paste('Method2_',i)]*(1 - data_all[r,"δ"]) + data_all[r,"I"]
          }
      }
      
      data_all['logKL'] <- log(data_all[paste('Method2_',i)])/log(data_all$L)
      data_all['logKY'] <- log(data_all[paste('Method2_',i)])/log(data_all$Y)
      data_all['logLY'] <- log(data_all$L)/log(data_all$Y)
      data_all['con'] <- 1/log(data_all$Y)
    }
    
#   Step 3: Output the result
    
    wb = createWorkbook()
    addWorksheet(wb,"Method2")
    writeData(wb,"Method2", data_all, startRow=1, rowNames=TRUE)
    saveWorkbook(wb, "MYMETHOD2.xlsx")
    
    