########1#########2#########3#########4#########5#########6#########7##########
#                                                                             #
#   2. Nehru Method2 Models (01/02/2023)                                      #
#                                                                             # 
#   This program estimates initial capital stock by the second approach from  #
#   Nehru's paper.  The model iterates the process 20 times to make the       #
#   result converge to a specific level.                                      #
#                                                                             #
#########1#########2#########3#########4#########5#########6#########7#########

#   load packages

    library(readxl)
    library(plm)
    library(stargazer)
    library(lmtest)
    library(openxlsx)

#   load database, set the variables
    
    data_all <- read_excel("MYMETHOD.xlsx")
    data_all <- data.frame(data_all)
    data_all <- data_all[,1:17]
    result <- data_all

#   STEP 1: Set the models

    M21 <- logKY ~ logKL
    M22 <- logKY ~ logKL + con
    M23 <- logKY ~ logLY
    M24 <- logKY ~ logLY + con
    
#   Step 2: Estimate the models using all countries
    clist <- list('ABW','AFG','AGO','AIA','ALB','AND','ARE','ARG','ATG','ATG',
                  'AUS','AUT','BDI','BEL','BEN','BFA','BGD','BGR','BHR','BHS',
                  'BLZ','BMU','BOL','BRA','BRB','BRN','BTN','BWA','CAF','CAN',
                  'CHE','CHL','CHN','CIV','CMR','COD','COG','COL','COM','CPV',
                  'CRI','CUB','CYM','CYP','DEU','DJI','DMA','DNK','DOM','DZA',
                  'ECU','EGY','ESP','ETH','FIN','FJI','FRA','FSM','GAB','GBR',
                  'GHA','GIN','GMB','GNB','GNQ','GRC','GRD','GRL','GTM','GUY',
                  'HKG','HND','HTI','HUN','IDN','IND','IRL','IRN','IRQ','ISL',
                  'ISR','ITA','JAM','JOR','JPN','KEN','KHM','KIR','KNA','KOR',
                  'KWT','LAO','LBN','LBR','LBY','LCA','LIE','LKA','LSO','LUX',
                  'MAC','MAR','MCO','MDG','MDV','MEX','MHL','MLI','MLT','MMR',
                  'MNG','MOZ','MRT','MSR','MUS','MWI','MYS','NAM','NCL','NER',
                  'NGA','NIC','NLD','NOR','NPL','NRU','NZL','OMN','PAK','PAN',
                  'PER','PHL','PLW','PNG','POL','PRI','PRT','PRY','PSE','PYF',
                  'QAT','ROU','RWA','SAU','SDN','SEN','SGP','SLB','SLE','SLV',
                  'SMR','SOM','STP','SUR','SWE','SWZ','SYC','SYR','TCA','TCD',
                  'TGO','THA','TON','TTO','TUN','TUR','TUV','TWN','TZA','UGA',
                  'URY','USA','VCT','VEN','VGB','VNM','VUT','WSM','ZAF','ZMB','ZWE'
    )
    
    result <- data.frame()
    
    for (c in clist)
      {
      data_test <- data_all[which(data_all$CCode==c),]
      data_test <- data_test[complete.cases(data_test), ]
      
      model1_all <- lm(formula = log(I) ~ Year, data = data_test)
      
      fit <- fitted(model1_all)
      fit <- exp(fit)
      
      grI <- coef(model1_all)
      
      iniK_var <- fit[2]/(grI[2] + data_test[1,"δ"])
      iniK_con <- fit[2]/(grI[2] + 0.04)
      Code <- data_test[1,"CCode"]
      
      for (r in 1:nrow(data_test)) {
        if (data_test[r,"start"]==1 && data_test[r, 'CCode']==Code){
          data_test[r,'Method4_K_var'] <- iniK_var
          data_test[r,'Method4_K_con'] <- iniK_con
        }}
      for (r in 1:nrow(data_test)) {
        if (data_test[r,"start"]==2){
          data_test[r,'Method4_K_var'] <- data_test[r-1,'Method4_K_var']*(1 - data_test[r,"δ"]) + data_test[r,"I"]
          data_test[r,'Method4_K_con'] <- data_test[r-1,'Method4_K_con']*0.95 + data_test[r,"I"]
        }
      }
      result <- rbind(result,data_test)
      }
    
#   Step 3: Output the result
    
    wb = createWorkbook()
    addWorksheet(wb,"Method4")
    writeData(wb,"Method4", result, startRow=1, rowNames=TRUE)
    saveWorkbook(wb, "MYMETHOD4.xlsx")
    
    