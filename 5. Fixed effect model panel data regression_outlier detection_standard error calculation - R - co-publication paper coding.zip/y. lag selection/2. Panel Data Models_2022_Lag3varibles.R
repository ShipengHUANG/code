########1#########2#########3#########4#########5#########6#########7##########
#                                                                             #
#   2. Panel Data Models (12/05/2022)                                         #
#                                                                             # 
#   This program estimates several panel data models of net investment rates  #
#   using 5-year-averaged data.  Choices are made about which measures of     #
#   net investment, initial capital stock, TFP, etc. to use in the baseline   #
#   models.  Alternative choices will be examined in later sensitivity        #
#   analyses.                                                                 #
#                                                                             #
#########1#########2#########3#########4#########5#########6#########7#########

    library(readxl)
    library(plm)
    library(stargazer)


#   load database, create new variables, and create two additional datasets 

    ctype <- c("text", "text", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric",
               "numeric", "numeric", "numeric", "numeric")
    
    data_all <- read_excel("FinalData5Year.xlsx", sheet = "Lag3",col_types = ctype)
    data_all <- data.frame(data_all)
    
    data_all$logGDPpco <- 100*log(data_all$GDPpc_o_1)
    data_all$logGDPpce <- 100*log(data_all$GDPpc_e_1)
    data_all$CapShr    <- 100*data_all$CapShr
        
    head(data_all)
    tail(data_all)
    
    data_all$NINV   <- data_all$NINV2
    data_all$logGDP <- data_all$logGDPpce
    data_all$grTFP  <- data_all$grTFP2
    
    summary(data_all)

    data_OECD <- subset(data_all, OECD==1)
    data_non  <- subset(data_all, OECD==0)
    

#   STEP 1: create five formulas, one for each specification of the capital
#           tax measure 

    fml1 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP 
    fml2 <- NINV ~ logGDP + grTFP + grE + CapShr + CorpGDP 
    fml3 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + CorpTax
    fml4 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + BrCapTax
    fml5 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + EMCapTax
    
    
#   Step 2: Estimate the models using all countries
    
    model1_all <- plm(formula = fml1, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model2_all <- plm(formula = fml2, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model3_all <- plm(formula = fml3, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model4_all <- plm(formula = fml4, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model5_all <- plm(formula = fml5, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    
    stargazer(model1_all, model2_all, model3_all, model4_all, model5_all, type = "text", 
              title="Table1: Model of Net Investment Rate for all 85 Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpco)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpGDP [+]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Lag CDPpc, TFP and Labor for one period"),
              align=TRUE, out="2022_models_Lag3variables_1.htm") 
    
    
    fml6 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax
    fml7 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + Open
    fml8 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + GovShr
    fml9 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + Infl
    fml10 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + PriceInv
    fml11 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + grHC
    
    model6_all <- plm(formula = fml6, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model7_all <- plm(formula = fml7, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model8_all <- plm(formula = fml8, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model9_all <- plm(formula = fml9, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model10_all <- plm(formula = fml10, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model11_all <- plm(formula = fml11, data = data_all, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    
    stargazer(model7_all, model8_all, model9_all, model10_all, model11_all, type = "text", 
              title="Table2: Model of Net Investment Rate for all 85 Countries with Control Variables", 
              covariate.labels=c("log(GDPpco)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]","TaxGDP [-]",
                                 "CapShr [+]","BrCapTax [+]","Open [-]","GovShr [-]","Infl [-]","PriceInv [-]","grHC [-]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Lag CDPpc, TFP and Labor for one period"),
              align=TRUE, out="2022_models_Lag3variables_2.htm")
    
#   STEP 3: Estimate the models using OECD countries
    
    model1_OECD <- plm(formula = fml1, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model2_OECD <- plm(formula = fml2, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model3_OECD <- plm(formula = fml3, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model4_OECD <- plm(formula = fml4, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model5_OECD <- plm(formula = fml5, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    
    stargazer(model1_OECD, model2_OECD, model3_OECD, model4_OECD, model5_OECD, type = "text", 
              title="Table3: Model of Net Investment Rate for 24 OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpco)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpGDP [+]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Lag CDPpc, TFP and Labor for one period"),
              align=TRUE, out="2022_models_Lag3variables_3.htm") 
    
    
    fml6 <- NINV ~ logGDP + grTFP + grE + TaxGDP + BrCapTax
    fml7 <- NINV ~ logGDP + grTFP + grE + TaxGDP + BrCapTax + Open
    fml8 <- NINV ~ logGDP + grTFP + grE + TaxGDP + BrCapTax + GovShr
    fml9 <- NINV ~ logGDP + grTFP + grE + TaxGDP + BrCapTax + Infl
    fml10 <- NINV ~ logGDP + grTFP + grE + TaxGDP + BrCapTax + PriceInv
    fml11 <- NINV ~ logGDP + grTFP + grE + TaxGDP + BrCapTax + grHC
    
    model6_OECD <- plm(formula = fml6, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model7_OECD <- plm(formula = fml7, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model8_OECD <- plm(formula = fml8, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model9_OECD <- plm(formula = fml9, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model10_OECD <- plm(formula = fml10, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model11_OECD <- plm(formula = fml11, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    
    stargazer(model7_OECD, model8_OECD, model9_OECD, model10_OECD, model11_OECD, type = "text", 
              title="Table4: Model of Net Investment Rate for 24 OECD Countries with Control Variables", 
              covariate.labels=c("log(GDPpco)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]","TaxGDP [-]",
                                 "BrCapTax [+]","Open [-]","GovShr [-]","Infl [-]","PriceInv [-]","grHC [-]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Lag CDPpc, TFP and Labor for one period"),
              align=TRUE, out="2022_models_Lag3variables_4.htm")
    
    
    
#   STEP 4: Estimate the models using non-OECD countries
    
    model1_non <- plm(formula = fml1, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model2_non <- plm(formula = fml2, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model3_non <- plm(formula = fml3, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model4_non <- plm(formula = fml4, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model5_non <- plm(formula = fml5, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    
    stargazer(model1_non, model2_non, model3_non, model4_non, model5_non, type = "text", 
              title="Table5: Model of Net Investment Rate for 61non-OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpco)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpGDP [+]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Lag CDPpc, TFP and Labor for one period"),
              align=TRUE, out="2022_models_Lag3variables_5.htm") 
    
    
    fml6 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax
    fml7 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + Open
    fml8 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + GovShr
    fml9 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + Infl
    fml10 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + PriceInv
    fml11 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + grHC
    
    model6_non <- plm(formula = fml6, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model7_non <- plm(formula = fml7, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model8_non <- plm(formula = fml8, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model9_non <- plm(formula = fml9, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model10_non <- plm(formula = fml10, data = data_non, 
                        index = c("CName", "Year"),
                        model = "within", effect = "twoways")
    model11_non <- plm(formula = fml11, data = data_non, 
                        index = c("CName", "Year"),
                        model = "within", effect = "twoways")
    
    stargazer(model7_non, model8_non, model9_non, model10_non, model11_non, type = "text", 
              title="Table6: Model of Net Investment Rate for 61 non-OECD Countries with Control Variables", 
              covariate.labels=c("log(GDPpco)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]","TaxGDP [-]",
                                 "CapShr [+]","BrCapTax [+]","Open [-]","GovShr [-]","Infl [-]","PriceInv [-]","grHC [-]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Lag CDPpc, TFP and Labor for one period"),
              align=TRUE, out="2022_models_Lag3variables_6.htm")