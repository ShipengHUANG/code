
    library(readxl)
    library(plm)


#   load database, create new variables, and create two additional datasets 

    data <- read_excel("FinalOECDData5Year.xlsx")
    data <- data.frame(data)
    data <- pdata.frame(data, index = c("CCode", "Year"))
    
    data$GDPpco  <- 100*log(data$GDPpco)
    data$GDPpce  <- 100*log(data$GDPpce)
    data$GDPpcna <- 100*log(data$GDPpcna)
    
    data$CapShr <- 100*data$CapShr
        
    head(data)
    tail(data)
    
    summary(data)


#   STEP 1: create four formulas, one for each specification of the capital
#           tax measure 

    fml1 <- NINV ~ GDPpco + lag(grTFP) + lag(grL) + CapShr + TaxGDP 
    fml2 <- NINV ~ GDPpco + lag(grTFP) + lag(grL) + CapShr + TaxGDP + CorpTax2
    fml3 <- NINV ~ GDPpco + lag(grTFP) + lag(grL) + CapShr + TaxGDP + BrCapTax2
    fml4 <- NINV ~ GDPpco + lag(grTFP) + lag(grL) + CapShr + TaxGDP + EMCapTax2
    
    
#   Step 2: Estimate the baseline models
    
    model1 <- plm(formula = fml1, data = data, 
                  model = "within", effect = "twoways")
    model2 <- plm(formula = fml2, data = data, 
                  model = "within", effect = "twoways")
    model3 <- plm(formula = fml3, data = data, 
                  model = "within", effect = "twoways")
    model4 <- plm(formula = fml4, data = data, 
                  model = "within", effect = "twoways")

    summary(model1)    
    summary(model2)    
    summary(model3)    
    summary(model4)    
    
    
#   STEP 3: create five alternative formulas, using control variables
    
    fml5 <- NINV ~ GDPpco + lag(grTFP) + lag(grL) + TaxGDP + BrCapTax2
    fml6 <- NINV ~ GDPpco + lag(grTFP) + lag(grL) + TaxGDP + BrCapTax2 + Open
    fml7 <- NINV ~ GDPpco + lag(grTFP) + lag(grL) + TaxGDP + BrCapTax2 + Infl
    fml8 <- NINV ~ GDPpco + lag(grTFP) + lag(grL) + TaxGDP + BrCapTax2 + PriceInv
    fml9 <- NINV ~ GDPpco + lag(grTFP) + lag(grL) + TaxGDP + BrCapTax2 + grHC

    
#   Step 4: Estimate the alternative models
    
    model5 <- plm(formula = fml5, data = data, 
                  model = "within", effect = "twoways")
    model6 <- plm(formula = fml6, data = data, 
                  model = "within", effect = "twoways")
    model7 <- plm(formula = fml7, data = data, 
                  model = "within", effect = "twoways")
    model8 <- plm(formula = fml8, data = data, 
                  model = "within", effect = "twoways")
    model9 <- plm(formula = fml9, data = data, 
                  model = "within", effect = "twoways")
    
    summary(model5)    
    summary(model6)    
    summary(model7)    
    summary(model8)
    summary(model9)

        
#   STEP 5: are the lags on TFP and L important?
    
    fml10 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP 
    fml11 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + CorpTax2
    fml12 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + BrCapTax2
    fml13 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + EMCapTax2
    
    
#   Step 6: restimate the baseline models
    
    model10 <- plm(formula = fml10, data = data, 
                  model = "within", effect = "twoways")
    model11 <- plm(formula = fml11, data = data, 
                  model = "within", effect = "twoways")
    model12 <- plm(formula = fml12, data = data, 
                  model = "within", effect = "twoways")
    model13 <- plm(formula = fml13, data = data, 
                  model = "within", effect = "twoways")
    
    summary(model10)    
    summary(model11)    
    summary(model12)    
    summary(model13)    
    
    
    
    
    