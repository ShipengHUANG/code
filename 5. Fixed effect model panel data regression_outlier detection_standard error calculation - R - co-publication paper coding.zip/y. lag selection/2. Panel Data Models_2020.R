
    library(readxl)
    library(plm)
    library(stargazer)


#   load database, create new variables, and create two additional datasets 

    data <- read_excel("FinalOECDData5Year.xlsx", sheet = "Lag2")
    data <- data.frame(data)
    data <- pdata.frame(data, index = c("CCode", "Year"))
    
    data$GDPpco  <- 100*log(data$GDPpco)
    data$GDPpce  <- 100*log(data$GDPpce)
    data$GDPpcna <- 100*log(data$GDPpcna)
    
    data$CapShr <- 100*data$CapShr
        
    head(data)
    tail(data)
    
    summary(data)


#   STEP 1: create four formulas, one for each specification of the capital
#           tax measure (lagged)

    fml1 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP 
    fml2 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + CorpTax2
    fml3 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + BrCapTax2
    fml4 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + EMCapTax2
    
    
#   Step 2: Estimate the baseline models
    
    model1 <- plm(formula = fml1, data = data, 
                  model = "within", effect = "twoways")
    model2 <- plm(formula = fml2, data = data, 
                  model = "within", effect = "twoways")
    model3 <- plm(formula = fml3, data = data, 
                  model = "within", effect = "twoways")
    model4 <- plm(formula = fml4, data = data, 
                  model = "within", effect = "twoways")

    stargazer(model1, model2, model3, model4, type = "text", 
              title="Table1: Model of Net Investment Rate for Major OECD Countries with Measures of CapTax (Reproduce past Results)", 
              covariate.labels=c("log(GDPpco) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpTax2 [+]","BrCapTax2 [+]","EMCapTax2 [+]"),
              notes = c("Using 2020 database. The sample period is 1965-2015. Lag TFP and Labor for one period."),
              align=TRUE, out="2020_models_1.htm")  
    
    
#   STEP 3: create five alternative formulas, using control variables
    
    fml5 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2
    fml6 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + Open
    fml7 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + Infl
    fml8 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + PriceInv
    fml9 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + grHC

    
#   Step 4: Estimate the alternative models
    
    model5 <- plm(formula = fml5, data = data, 
                  model = "within", effect = "twoways")
    model6 <- plm(formula = fml6, data = data, 
                  model = "within", effect = "twoways")
    model7 <- plm(formula = fml7, data = data, 
                  model = "within", effect = "twoways")
    model8 <- plm(formula = fml8, data = data, 
                  model = "within", effect = "twoways")
    model9 <- plm(formula = fml9, data = data, 
                  model = "within", effect = "twoways")
    
    stargazer(model5, model6, model7, model8, model9, type = "text", 
              title="Table2: Model of Net Investment Rate for Major OECD with Control Variables", 
              covariate.labels=c("log(GDPpco) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "TaxGDP [-]","BrCapTax2 [+]","Openness [-]","Inflation [-]",
                                 "Price level of Investment [-]","Growth of Human Capital [-]"),
              notes = c("Using 2020 database. The sample period is 1965-2015. Lag TFP and Labor for one period."),
              align=TRUE, out="2020_models_2.htm")  

        
#   STEP 5: are the lags on TFP and L important?
    
    #   load database, create new variables, and create two additional datasets 
    
    data <- read_excel("FinalOECDData5Year.xlsx", sheet = "Current")
    data <- data.frame(data)
    data <- pdata.frame(data, index = c("CCode", "Year"))
    
    data$GDPpco  <- 100*log(data$GDPpco)
    data$GDPpce  <- 100*log(data$GDPpce)
    data$GDPpcna <- 100*log(data$GDPpcna)
    
    data$CapShr <- 100*data$CapShr
    
    head(data)
    tail(data)
    
    summary(data)
    
    
    #   STEP 1: create four formulas, one for each specification of the capital
    #           tax measure (current)
    
    fml1 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP 
    fml2 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + CorpTax2
    fml3 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + BrCapTax2
    fml4 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + EMCapTax2
    
    
    #   Step 2: Estimate the baseline models
    
    model1 <- plm(formula = fml1, data = data, 
                  model = "within", effect = "twoways")
    model2 <- plm(formula = fml2, data = data, 
                  model = "within", effect = "twoways")
    model3 <- plm(formula = fml3, data = data, 
                  model = "within", effect = "twoways")
    model4 <- plm(formula = fml4, data = data, 
                  model = "within", effect = "twoways")
    
    stargazer(model1, model2, model3, model4, type = "text", 
              title="Table3: Model of Net Investment Rate for Major OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpco) [-]","Growth of TFP [+]","Growth of Labor [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpTax2 [+]","BrCapTax2 [+]","EMCapTax2 [+]"),
              notes = c("Using 2020 database. The sample period is 1965-2015. Using current TFP and Labor."),
              align=TRUE, out="2020_models_3.htm")  
    
    
    #   STEP 3: create five alternative formulas, using control variables
    
    fml5 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2
    fml6 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + Open
    fml7 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + Infl
    fml8 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + PriceInv
    fml9 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + grHC
    
    
    #   Step 4: Estimate the alternative models
    
    model5 <- plm(formula = fml5, data = data, 
                  model = "within", effect = "twoways")
    model6 <- plm(formula = fml6, data = data, 
                  model = "within", effect = "twoways")
    model7 <- plm(formula = fml7, data = data, 
                  model = "within", effect = "twoways")
    model8 <- plm(formula = fml8, data = data, 
                  model = "within", effect = "twoways")
    model9 <- plm(formula = fml9, data = data, 
                  model = "within", effect = "twoways")
    
    stargazer(model5, model6, model7, model8, model9, type = "text", 
              title="Table4: Model of Net Investment Rate for Major OECD Countries with Control Variables", 
              covariate.labels=c("log(GDPpco) [-]","Growth of TFP [+]","Growth of Labor [+]",
                                 "TaxGDP [-]","BrCapTax2 [+]","Openness [-]","Inflation [-]",
                                 "Price level of Investment [-]","Growth of Human Capital [-]"),
              notes = c("Using 2020 database. The sample period is 1965-2015. Using current TFP and Labor."),
              align=TRUE, out="2020_models_4.htm")  
    
    #   Lagged GDPpc as well?
    #   load database, create new variables, and create two additional datasets 
    
    data <- read_excel("FinalOECDData5Year.xlsx", sheet = "Lag3")
    data <- data.frame(data)
    data <- pdata.frame(data, index = c("CCode", "Year"))
    
    data$GDPpco  <- 100*log(data$GDPpco)
    data$GDPpce  <- 100*log(data$GDPpce)
    data$GDPpcna <- 100*log(data$GDPpcna)
    
    data$CapShr <- 100*data$CapShr
    
    head(data)
    tail(data)
    
    summary(data)
    
    
    #   STEP 1: create four formulas, one for each specification of the capital
    #           tax measure (lagged)
    
    fml1 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP 
    fml2 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + CorpTax2
    fml3 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + BrCapTax2
    fml4 <- NINV ~ GDPpco + grTFP + grL + CapShr + TaxGDP + EMCapTax2
    
    
    #   Step 2: Estimate the baseline models
    
    model1 <- plm(formula = fml1, data = data, 
                  model = "within", effect = "twoways")
    model2 <- plm(formula = fml2, data = data, 
                  model = "within", effect = "twoways")
    model3 <- plm(formula = fml3, data = data, 
                  model = "within", effect = "twoways")
    model4 <- plm(formula = fml4, data = data, 
                  model = "within", effect = "twoways")
    
    stargazer(model1, model2, model3, model4, type = "text", 
              title="Table5: Model of Net Investment Rate for Major OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpco)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpTax2 [+]","BrCapTax2 [+]","EMCapTax2 [+]"),
              notes = c("Using 2020 database. The sample period is 1965-2015. Lag GDPpc, TFP and Labor for one period."),
              align=TRUE, out="2020_models_5.htm")  
    
    
    #   STEP 3: create five alternative formulas, using control variables
    
    fml5 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2
    fml6 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + Open
    fml7 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + Infl
    fml8 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + PriceInv
    fml9 <- NINV ~ GDPpco + grTFP + grL + TaxGDP + BrCapTax2 + grHC
    
    
    #   Step 4: Estimate the alternative models
    
    model5 <- plm(formula = fml5, data = data, 
                  model = "within", effect = "twoways")
    model6 <- plm(formula = fml6, data = data, 
                  model = "within", effect = "twoways")
    model7 <- plm(formula = fml7, data = data, 
                  model = "within", effect = "twoways")
    model8 <- plm(formula = fml8, data = data, 
                  model = "within", effect = "twoways")
    model9 <- plm(formula = fml9, data = data, 
                  model = "within", effect = "twoways")
    
    stargazer(model5, model6, model7, model8, model9, type = "text", 
              title="Table6: Model of Net Investment Rate for Major OECD Countries with Control Variables", 
              covariate.labels=c("log(GDPpco)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "TaxGDP [-]","BrCapTax2 [+]","Openness [-]","Inflation [-]",
                                 "Price level of Investment [-]","Growth of Human Capital [-]"),
              notes = c("Using 2020 database. The sample period is 1965-2015. Lag GDPpc, TFP and Labor for one period."),
              align=TRUE, out="2020_models_6.htm") 