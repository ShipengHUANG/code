########1#########2#########3#########4#########5#########6#########7##########
#                                                                             #
#   2. Panel Data Models (12/05/2022)                                         #
#                                                                             # 
#   This program estimates several panel data models of net investment rates  #
#   using 5-year-averaged data.  Choices are made about which measures of     #
#   net investment, initial capital stock, TFP, etc. to use in the baseline   #
#   models.  Alternative choices will be examined in later sensitivity        #
#   analyses.                                                                 #
#                                                                             #
#########1#########2#########3#########4#########5#########6#########7#########

    library(readxl)
    library(plm)
    library(stargazer)


#   load database, create new variables, and create two additional datasets 

    ctype <- c("text", "text", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric",
               "numeric", "numeric", "numeric", "numeric")
    
    data_all <- read_excel("FinalData5Year.xlsx", sheet = "Lag2",col_types = ctype)
    data_all <- data.frame(data_all)
    
    data_all$logGDPpco <- 100*log(data_all$GDPpc_o_1)
    data_all$logGDPpce <- 100*log(data_all$GDPpc_e_1)
    data_all$CapShr    <- 100*data_all$CapShr
        
    head(data_all)
    tail(data_all)
    
    data_all$NINV   <- data_all$NINV2
    data_all$logGDP <- data_all$logGDPpce
    data_all$grTFP  <- data_all$grTFP2
    
    summary(data_all)

    data_OECD <- subset(data_all, OECD==1)
    #data_OECD <- data_OECD[-which(data_OECD$Year==2015),]
    #data_OECD <- data_OECD[-which(data_OECD$CName=="Luxembourg"),]
    #data_OECD <- data_OECD[-which(data_OECD$CName=="Turkey"),]
    #data_OECD <- data_OECD[-which(data_OECD$CName=="Iceland"),]
    data_non  <- subset(data_all, OECD==0)
    

#   STEP 1: create five formulas, one for each specification of the capital
#           tax measure 

    fml1 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP 
    fml2 <- NINV ~ logGDP + grTFP + grE + CapShr + CorpGDP 
    fml3 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + CorpTax
    fml4 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + BrCapTax
    fml5 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + EMCapTax
    
    
#   Step 2: Estimate the models using all countries
    
    'model1_all <- plm(formula = fml1, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model2_all <- plm(formula = fml2, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model3_all <- plm(formula = fml3, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model4_all <- plm(formula = fml4, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model5_all <- plm(formula = fml4, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    
    summary(model1_all)    
    summary(model2_all)    
    summary(model3_all)    
    summary(model4_all)    
    summary(model5_all)'
    
    
#   STEP 3: Estimate the models using OECD countries
    
    model1_OECD <- plm(formula = fml1, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model2_OECD <- plm(formula = fml2, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model3_OECD <- plm(formula = fml3, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model4_OECD <- plm(formula = fml4, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model5_OECD <- plm(formula = fml5, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")   
    
    stargazer(model1_OECD, model3_OECD, model4_OECD, model5_OECD, type = "text", 
              title="Table1: Model of Net Investment Rate for Major OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpce) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Lag TFP and Labor for one period."),
              align=TRUE, out="2022_models_1.htm")   
    
    data_OECD <- data_OECD[-which(data_OECD$Year==2015),]
    data_OECD <- data_OECD[-which(data_OECD$CName=="Luxembourg"),]
    data_OECD <- data_OECD[-which(data_OECD$CName=="Turkey"),]
    data_OECD <- data_OECD[-which(data_OECD$CName=="Iceland"),]
    
    model1_OECD <- plm(formula = fml1, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model2_OECD <- plm(formula = fml2, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model3_OECD <- plm(formula = fml3, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model4_OECD <- plm(formula = fml4, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model5_OECD <- plm(formula = fml5, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")   
    
    stargazer(model1_OECD, model3_OECD, model4_OECD, model5_OECD, type = "text", 
              title="Table4: Model of Net Investment Rate for Major OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpce) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2014. Drop the Luxembourg, Turkey and Iceland. Lag TFP and Labor for one period."),
              align=TRUE, out="2022_models_4.htm")     
    
    
    
    
    
    
    ctype <- c("text", "text", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric",
               "numeric", "numeric", "numeric", "numeric")
    
    data_all <- read_excel("FinalData5Year.xlsx", sheet = "Current",col_types = ctype)
    data_all <- data.frame(data_all)
    
    data_all$logGDPpco <- 100*log(data_all$GDPpc_o_1)
    data_all$logGDPpce <- 100*log(data_all$GDPpc_e_1)
    data_all$CapShr    <- 100*data_all$CapShr
    
    head(data_all)
    tail(data_all)
    
    data_all$NINV   <- data_all$NINV2
    data_all$logGDP <- data_all$logGDPpce
    data_all$grTFP  <- data_all$grTFP2
    
    summary(data_all)
    
    data_OECD <- subset(data_all, OECD==1)
    data_non  <- subset(data_all, OECD==0)
    
    model1_OECD <- plm(formula = fml1, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model2_OECD <- plm(formula = fml2, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model3_OECD <- plm(formula = fml3, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model4_OECD <- plm(formula = fml4, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model5_OECD <- plm(formula = fml5, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")   
    
    stargazer(model1_OECD, model3_OECD, model4_OECD, model5_OECD, type = "text", 
              title="Table2: Model of Net Investment Rate for Major OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpce) [-]","Growth of TFP [+]","Growth of Labor [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Using current GDPpc, TFP and Labor."),
              align=TRUE, out="2022_models_2.htm")  
    
    data_OECD <- data_OECD[-which(data_OECD$Year==2015),]
    data_OECD <- data_OECD[-which(data_OECD$CName=="Luxembourg"),]
    data_OECD <- data_OECD[-which(data_OECD$CName=="Turkey"),]
    data_OECD <- data_OECD[-which(data_OECD$CName=="Iceland"),]
    
    model1_OECD <- plm(formula = fml1, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model2_OECD <- plm(formula = fml2, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model3_OECD <- plm(formula = fml3, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model4_OECD <- plm(formula = fml4, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model5_OECD <- plm(formula = fml5, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")   
    
    stargazer(model1_OECD, model3_OECD, model4_OECD, model5_OECD, type = "text", 
              title="Table5: Model of Net Investment Rate for Major OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpce) [-]","Growth of TFP [+]","Growth of Labor [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2014. Drop the Luxembourg, Turkey and Iceland. Using current GDPpc, TFP and Labor."),
              align=TRUE, out="2022_models_5.htm") 
    
    
    
    
    
    
    ctype <- c("text", "text", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric",
               "numeric", "numeric", "numeric", "numeric")
    
    data_all <- read_excel("FinalData5Year.xlsx", sheet = "Lag3",col_types = ctype)
    data_all <- data.frame(data_all)
    
    data_all$logGDPpco <- 100*log(data_all$GDPpc_o_1)
    data_all$logGDPpce <- 100*log(data_all$GDPpc_e_1)
    data_all$CapShr    <- 100*data_all$CapShr
    
    head(data_all)
    tail(data_all)
    
    data_all$NINV   <- data_all$NINV2
    data_all$logGDP <- data_all$logGDPpce
    data_all$grTFP  <- data_all$grTFP2
    
    summary(data_all)
    
    data_OECD <- subset(data_all, OECD==1)
    data_non  <- subset(data_all, OECD==0)
    
    model1_OECD <- plm(formula = fml1, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model2_OECD <- plm(formula = fml2, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model3_OECD <- plm(formula = fml3, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model4_OECD <- plm(formula = fml4, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model5_OECD <- plm(formula = fml5, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")   
    
    stargazer(model1_OECD, model3_OECD, model4_OECD, model5_OECD, type = "text", 
              title="Table3: Model of Net Investment Rate for Major OECD Countries with Measures of CapTax (THE SETTING IS GOOD ENOUGH TO USE)", 
              covariate.labels=c("log(GDPpce)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Lag GDPpc, TFP and Labor for one period."),
              align=TRUE, out="2022_models_3.htm")  
    
    data_OECD <- data_OECD[-which(data_OECD$Year==2015),]
    data_OECD <- data_OECD[-which(data_OECD$CName=="Luxembourg"),]
    data_OECD <- data_OECD[-which(data_OECD$CName=="Turkey"),]
    data_OECD <- data_OECD[-which(data_OECD$CName=="Iceland"),]
    
    model1_OECD <- plm(formula = fml1, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model2_OECD <- plm(formula = fml2, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model3_OECD <- plm(formula = fml3, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model4_OECD <- plm(formula = fml4, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model5_OECD <- plm(formula = fml5, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")   
    
    stargazer(model1_OECD, model3_OECD, model4_OECD, model5_OECD, type = "text", 
              title="Table6: Model of Net Investment Rate for Major OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpce)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2014. Drop the Luxembourg, Turkey and Iceland. Lag GDPpc, TFP and Labor for one period."),
              align=TRUE, out="2022_models_6.htm") 
    
#   STEP 4: Estimate the models using non-OECD countries
    
    'model1_non <- plm(formula = fml1, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model2_non <- plm(formula = fml2, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model3_non <- plm(formula = fml3, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model4_non <- plm(formula = fml4, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model5_non <- plm(formula = fml5, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    
    summary(model1_non)    
    summary(model2_non)    
    summary(model3_non)    
    summary(model4_non)    
    summary(model5_non) 
    '
    