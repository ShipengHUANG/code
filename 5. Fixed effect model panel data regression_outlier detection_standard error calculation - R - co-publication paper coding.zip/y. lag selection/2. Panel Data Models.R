########1#########2#########3#########4#########5#########6#########7##########
#                                                                             #
#   2. Panel Data Models (12/05/2022)                                         #
#                                                                             # 
#   This program estimates several panel data models of net investment rates  #
#   using 5-year-averaged data.  Choices are made about which measures of     #
#   net investment, initial capital stock, TFP, etc. to use in the baseline   #
#   models.  Alternative choices will be examined in later sensitivity        #
#   analyses.                                                                 #
#                                                                             #
#########1#########2#########3#########4#########5#########6#########7#########

    library(readxl)
    library(plm)
    library(stargazer)


#   load database, create new variables, and create two additional datasets 

    ctype <- c("text", "text", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric",
               "numeric", "numeric", "numeric", "numeric", "numeric",
               "numeric", "numeric", "numeric", "numeric", "numeric",
               "numeric", "numeric")
    
    data_all <- read_excel("FinalData5Year.xlsx", col_types = ctype)
    data_all <- data.frame(data_all)
    
    data_all$logGDPpco <- 100*log(data_all$lagGDPpco)
    data_all$logGDPpce <- 100*log(data_all$lagGDPpce)
    data_all$CapShr    <- 100*data_all$CapShr
        
    head(data_all)
    tail(data_all)
    
    data_all$NINV   <- data_all$NINV2
    data_all$logGDP <- data_all$logGDPpce
    data_all$grTFP  <- data_all$laggrTFP2
    data_all$grE    <- data_all$laggrE
    
    summary(data_all)

    data_OECD <- subset(data_all, OECD==1)
    data_non  <- subset(data_all, OECD==0)
    

#   STEP 1: create five formulas, one for each specification of the capital
#           tax measure 

    fml1 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP 
    fml2 <- NINV ~ logGDP + grTFP + grE + CapShr + CorpGDP 
    fml3 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + CorpTax
    fml4 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + BrCapTax
    fml5 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + EMCapTax
    
    
#   Step 2: Estimate the models using all countries
    
    model1_all <- plm(formula = fml1, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model2_all <- plm(formula = fml2, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model3_all <- plm(formula = fml3, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model4_all <- plm(formula = fml4, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model5_all <- plm(formula = fml4, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    
    summary(model1_all)    
    summary(model2_all)    
    summary(model3_all)    
    summary(model4_all)    
    summary(model5_all)
    
    stargazer(model1_all, model2_all, model3_all, model4_all, model5_all, type = "text", 
              title="Table1: Model of Net Investment Rate for all 85 Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpco)(-1) [-]","Growth of TFP(-1) [+]","Growth of Labor(-1) [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpGDP [+]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. Lag CDPpc, TFP and Labor for one period"),
              align=TRUE, out="2022_models_all_1.htm") 
    
    
#   STEP 3: Estimate the models using OECD countries
    
    model1_OECD <- plm(formula = fml1, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model2_OECD <- plm(formula = fml2, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model3_OECD <- plm(formula = fml3, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model4_OECD <- plm(formula = fml4, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model5_OECD <- plm(formula = fml5, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    

    summary(model1_OECD)    
    summary(model2_OECD)    
    summary(model3_OECD)    
    summary(model4_OECD)    
    summary(model5_OECD)    
    
    
#   STEP 4: Estimate the models using non-OECD countries
    
    model1_non <- plm(formula = fml1, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model2_non <- plm(formula = fml2, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model3_non <- plm(formula = fml3, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model4_non <- plm(formula = fml4, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model5_non <- plm(formula = fml5, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    
    summary(model1_non)    
    summary(model2_non)    
    summary(model3_non)    
    summary(model4_non)    
    summary(model5_non)    
    