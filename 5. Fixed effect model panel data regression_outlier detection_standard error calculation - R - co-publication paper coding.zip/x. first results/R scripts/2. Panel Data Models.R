########1#########2#########3#########4#########5#########6#########7##########
#                                                                             #
#   2. Panel Data Models (12/05/2022)                                         #
#                                                                             # 
#   This program estimates several panel data models of net investment rates  #
#   using 5-year-averaged data.  Choices are made about which measures of     #
#   net investment, initial capital stock, TFP, etc. to use in the baseline   #
#   models.  Alternative choices will be examined in later sensitivity        #
#   analyses.                                                                 #
#                                                                             #
#########1#########2#########3#########4#########5#########6#########7#########


    
    library(readxl)
    library(plm)
    library(stargazer)
    library(lmtest)
    library(openxlsx)



#   load database, create new variables, and create two additional datasets 

    ctype <- c("text", "text", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric",
               "numeric", "numeric", "numeric", "numeric")
    
    data_all <- read_excel("FinalData5Year.xlsx", col_types = ctype)
    data_all <- data.frame(data_all)
    
    data_all$logGDPpco <- 100*log(data_all$GDPpc_o_1)
    data_all$logGDPpce <- 100*log(data_all$GDPpc_e_1)
    data_all$CapShr    <- 100*data_all$CapShr
        
    head(data_all)
    tail(data_all)
    
    data_all$NINV   <- data_all$NINV2
    data_all$logGDP <- data_all$logGDPpce
    data_all$grTFP  <- data_all$grTFP2
    
    summary(data_all)

    data_OECD <- subset(data_all, OECD==1)
    data_non  <- subset(data_all, OECD==0)
    

#   STEP 1: create five formulas, one for each specification of the capital
#           tax measure 

    fml1 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP 
    fml2 <- NINV ~ logGDP + grTFP + grE + CapShr + CorpGDP 
    fml3 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + CorpTax
    fml4 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + BrCapTax
    fml5 <- NINV ~ logGDP + grTFP + grE + CapShr + TaxGDP + EMCapTax
    
    fml6 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax
    fml7 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + Open
    fml8 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + GovShr
    fml9 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + Infl
    fml10 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + PriceInv
    fml11 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + BrCapTax + grHC    

    fml62 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + CorpTax
    fml72 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + CorpTax + Open
    fml82 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + CorpTax + GovShr
    fml92 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + CorpTax + Infl
    fml102 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + CorpTax + PriceInv
    fml112 <- NINV ~ logGDP + grTFP + grE + TaxGDP + CapShr + CorpTax + grHC    
    
#   Step 2: Estimate the models using all countries
    
    model1_all <- plm(formula = fml1, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model2_all <- plm(formula = fml2, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model3_all <- plm(formula = fml3, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model4_all <- plm(formula = fml4, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model5_all <- plm(formula = fml5, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model6_all <- plm(formula = fml6, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model7_all <- plm(formula = fml7, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model8_all <- plm(formula = fml8, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model9_all <- plm(formula = fml9, data = data_all, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model10_all <- plm(formula = fml10, data = data_all, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model11_all <- plm(formula = fml11, data = data_all, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")

    stargazer(model1_all, model2_all, model3_all, model4_all, model5_all, type = "text", 
              title="Table1: Model of Net Investment Rate for all 85 Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpc) [-]","Growth of TFP [+]","Growth of Labor [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpGDP [+]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. The data of GDPpc is the beginning year value of each average year"),
              align=TRUE, out="2022_models_1.htm") 
    
    stargazer(model7_all, model8_all, model9_all, model10_all, model11_all, type = "text", 
              title="Table2: Model of Net Investment Rate for all 85 Countries with Control Variables", 
              covariate.labels=c("log(GDPpc) [-]","Growth of TFP [+]","Growth of Labor [+]","TaxGDP [-]",
                                 "CapShr [+]","BrCapTax [+]","Open [-]","GovShr [-]","Infl [-]","PriceInv [+]","grHC [-]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. The data of GDPpc is the beginning year value of each average year"),
              align=TRUE, out="2022_models_2.htm")     
    
#   STEP 3: Estimate the models using OECD countries
    
    model1_OECD <- plm(formula = fml1, data = data_OECD, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model2_OECD <- plm(formula = fml2, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model3_OECD <- plm(formula = fml3, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model4_OECD <- plm(formula = fml4, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")    
    model5_OECD <- plm(formula = fml5, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model6_OECD <- plm(formula = fml62, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model7_OECD <- plm(formula = fml72, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model8_OECD <- plm(formula = fml82, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model9_OECD <- plm(formula = fml92, data = data_OECD, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model10_OECD <- plm(formula = fml102, data = data_OECD, 
                        index = c("CName", "Year"),
                        model = "within", effect = "twoways")
    model11_OECD <- plm(formula = fml112, data = data_OECD, 
                        index = c("CName", "Year"),
                        model = "within", effect = "twoways")
    
    stargazer(model1_OECD, model2_OECD, model3_OECD, model4_OECD, model5_OECD, type = "text", 
              title="Table3: Model of Net Investment Rate for 24 OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpco) [-]","Growth of TFP [+]","Growth of Labor [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpGDP [+]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. The data of GDPpc is the beginning year value of each average year"),
              align=TRUE, out="2022_models_3.htm") 
    
    stargazer(model7_OECD, model8_OECD, model9_OECD, model10_OECD, model11_OECD, type = "text", 
              title="Table4: Model of Net Investment Rate for 24 OECD Countries with Control Variables", 
              covariate.labels=c("log(GDPpco) [-]","Growth of TFP [+]","Growth of Labor [+]","TaxGDP [-]",
                                 "CapShr [+]","BrCapTax [+]","Open [-]","GovShr [-]","Infl [-]","PriceInv [+]","grHC [-]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. The data of GDPpc is the beginning year value of each average year"),
              align=TRUE, out="2022_models_4.htm")

#   STEP 4: Estimate the models using non-OECD countries
    
    model1_non <- plm(formula = fml1, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model2_non <- plm(formula = fml2, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model3_non <- plm(formula = fml3, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model4_non <- plm(formula = fml4, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model5_non <- plm(formula = fml5, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")    
    model6_non <- plm(formula = fml6, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model7_non <- plm(formula = fml7, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model8_non <- plm(formula = fml8, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model9_non <- plm(formula = fml9, data = data_non, 
                      index = c("CName", "Year"),
                      model = "within", effect = "twoways")
    model10_non <- plm(formula = fml10, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    model11_non <- plm(formula = fml11, data = data_non, 
                       index = c("CName", "Year"),
                       model = "within", effect = "twoways")
    
    stargazer(model1_non, model2_non, model3_non, model4_non, model5_non, type = "text", 
              title="Table5: Model of Net Investment Rate for 61 non-OECD Countries with Measures of CapTax", 
              covariate.labels=c("log(GDPpco) [-]","Growth of TFP [+]","Growth of Labor [+]",
                                 "CapShr [+]","TaxGDP [-]","CorpGDP [+]","CorpTax [+]","BrCapTax [+]","EMCapTax [+]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. The data of GDPpc is the beginning year value of each average year"),
              align=TRUE, out="2022_models_5.htm")
    
    stargazer(model7_non, model8_non, model9_non, model10_non, model11_non, type = "text", 
              title="Table6: Model of Net Investment Rate for 61 non-OECD Countries with Control Variables", 
              covariate.labels=c("log(GDPpco) [-]","Growth of TFP [+]","Growth of Labor [+]","TaxGDP [-]",
                                 "CapShr [+]","BrCapTax [+]","Open [-]","GovShr [-]","Infl [-]","PriceInv [+]","grHC [-]"),
              notes = c("Using 2022 database. The sample period is 1965-2019. The data of GDPpc is the beginning year value of each average year"),
              align=TRUE, out="2022_models_6.htm")
    
# STEP 4: Test the Heteroskedasticity (BP test)
    
    dflist <- list(model1_all,model2_all,model3_all,model4_all,model5_all,
                model6_all,model7_all,model8_all,model9_all,model10_all,model11_all,
                model1_OECD,model2_OECD,model3_OECD,model4_OECD,model5_OECD,
                model6_OECD,model7_OECD,model8_OECD,model9_OECD,model10_OECD,model11_OECD,
                model1_non,model2_non,model3_non,model4_non,model5_non,
                model6_non,model7_non,model8_non,model9_non,model10_non,model11_non)
    
    for (r in dflist){
      BPtest <- bptest(r)
      BP.p <- BPtest[4]
      if (BP.p<0.05){print("Residuals are Heteroskedasticity")}else{print("without heteroscedasticity")}
    }

# STEP 5: Since there are heteroskedasticity, computing an array of standard errors for various estimators
    
    Vw <- function(x) vcovHC(x, method = "white1")
    Vcx <- function(x) vcovHC(x, cluster = "group", method = "arellano")
    Vct <- function(x) vcovHC(x, cluster = "time", method = "arellano")
    Vcxt <- function(x) Vcx(x) + Vct(x) - Vw(x)
    Vct.L <- function(x) vcovSCC(x, wj = function(j, maxlag) 1)
    Vnw.L <- function(x) vcovNW(x)
    Vscc.L <- function(x) vcovSCC(x)
    Vcxt.L <- function(x) Vct.L(x) + Vcx(x) - vcovNW(x, wj = function(j, maxlag) 1)
    
    vcovs <- c(vcov, Vw, Vcx, Vct, Vcxt, Vct.L, Vnw.L, Vscc.L, Vcxt.L)
    names(vcovs) <- c("OLS", "Vw", "Vcx", "Vct", "Vcxt", "Vct.L", "Vnw.L",
                      "Vscc.L", "Vcxt.L")
    
    cfrtab <- function(mod, vcovs, ...) {
      cfrtab <- matrix(nrow = length(coef(mod)), ncol = 1 + length(vcovs))
      dimnames(cfrtab) <- list(paste(names(coef(mod)),substring(deparse(substitute(mod)),4)),
                               c("Coefficient", paste("s.e.", names(vcovs))))
      cfrtab[,1] <- coef(mod)
      for(i in 1:length(vcovs)) {
        myvcov = vcovs[[i]]
        cfrtab[ , 1 + i] <- sqrt(diag(myvcov(mod)))
      }
      return(t(round(cfrtab, 4)))
    }

    stderr1_all <- data.frame(cfrtab(model1_all, vcovs))
    stderr2_all <- data.frame(cfrtab(model2_all, vcovs))
    stderr3_all <- data.frame(cfrtab(model3_all, vcovs))
    stderr4_all <- data.frame(cfrtab(model4_all, vcovs))
    stderr5_all <- data.frame(cfrtab(model5_all, vcovs))
    stderr6_all <- data.frame(cfrtab(model6_all, vcovs))
    stderr7_all <- data.frame(cfrtab(model7_all, vcovs))
    stderr8_all <- data.frame(cfrtab(model8_all, vcovs))
    stderr9_all <- data.frame(cfrtab(model9_all, vcovs))
    stderr10_all <- data.frame(cfrtab(model10_all, vcovs))
    stderr11_all <- data.frame(cfrtab(model11_all, vcovs))
    
    stderr1_OECD <- data.frame(cfrtab(model1_OECD, vcovs))
    stderr2_OECD <- data.frame(cfrtab(model2_OECD, vcovs))
    stderr3_OECD <- data.frame(cfrtab(model3_OECD, vcovs))
    stderr4_OECD <- data.frame(cfrtab(model4_OECD, vcovs))
    stderr5_OECD <- data.frame(cfrtab(model5_OECD, vcovs))
    stderr6_OECD <- data.frame(cfrtab(model6_OECD, vcovs))
    stderr7_OECD <- data.frame(cfrtab(model7_OECD, vcovs))
    stderr8_OECD <- data.frame(cfrtab(model8_OECD, vcovs))
    stderr9_OECD <- data.frame(cfrtab(model9_OECD, vcovs))
    stderr10_OECD <- data.frame(cfrtab(model10_OECD, vcovs))
    stderr11_OECD <- data.frame(cfrtab(model11_OECD, vcovs))
    
    stderr1_non <- data.frame(cfrtab(model1_non, vcovs))
    stderr2_non <- data.frame(cfrtab(model2_non, vcovs))
    stderr3_non <- data.frame(cfrtab(model3_non, vcovs))
    stderr4_non <- data.frame(cfrtab(model4_non, vcovs))
    stderr5_non <- data.frame(cfrtab(model5_non, vcovs))
    stderr6_non <- data.frame(cfrtab(model6_non, vcovs))
    stderr7_non <- data.frame(cfrtab(model7_non, vcovs))
    stderr8_non <- data.frame(cfrtab(model8_non, vcovs))
    stderr9_non <- data.frame(cfrtab(model9_non, vcovs))
    stderr10_non <- data.frame(cfrtab(model10_non, vcovs))
    stderr11_non <- data.frame(cfrtab(model11_non, vcovs))
    
    wb = createWorkbook()
    
    addWorksheet(wb,"Model1")
    writeData(wb,"Model1", stderr1_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model1", stderr1_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model1", stderr1_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model2")
    writeData(wb,"Model2", stderr2_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model2", stderr2_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model2", stderr2_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model3")
    writeData(wb,"Model3", stderr3_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model3", stderr3_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model3", stderr3_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model4")
    writeData(wb,"Model4", stderr4_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model4", stderr4_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model4", stderr4_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model5")
    writeData(wb,"Model5", stderr5_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model5", stderr5_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model5", stderr5_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model6")
    writeData(wb,"Model6", stderr6_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model6", stderr6_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model6", stderr6_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model7")
    writeData(wb,"Model7", stderr7_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model7", stderr7_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model7", stderr7_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model8")
    writeData(wb,"Model8", stderr8_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model8", stderr8_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model8", stderr8_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model9")
    writeData(wb,"Model9", stderr9_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model9", stderr9_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model9", stderr9_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model10")
    writeData(wb,"Model10", stderr10_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model10", stderr10_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model10", stderr10_non, startRow=30, rowNames=TRUE)
    addWorksheet(wb,"Model11")
    writeData(wb,"Model11", stderr11_all, startRow=1, rowNames=TRUE)
    writeData(wb,"Model11", stderr11_OECD, startRow=15, rowNames=TRUE)
    writeData(wb,"Model11", stderr11_non, startRow=30, rowNames=TRUE)
    
    saveWorkbook(wb, "Standard Error Summary.xlsx")

    

    
    
    
    