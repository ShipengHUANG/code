########1#########2#########3#########4#########5#########6#########7##########
#                                                                             #
#   1B. Prelim Analysis (Annual, OECD (12/02/2022)                            #
#                                                                             # 
#   This program conducts some preliminary analysis of investment data        #
#   in OECD and non-OECD countries using annual data and OECD countries.      #
#                                                                             #
#########1#########2#########3#########4#########5#########6#########7#########

    library(readxl)
    library(ggplot2)
    library(plm)


#   load database 

    ctype <- c("text", "text", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric", 
               "numeric", "numeric", "numeric", "numeric", "numeric",
               "numeric", "numeric", "numeric", "numeric")
    
    dat <- read_excel("FinalData5Year.xlsx", col_types = ctype)
    dat <- data.frame(dat)
    
    dat <- subset(dat, OECD==1)
    
    dat$logGDPpco <- log(dat$GDPpc_o_1)
    dat$logGDPpce <- log(dat$GDPpc_e_1)
    
    head(dat)
    tail(dat)
    
    summary(dat)


    #   STEP 1: create some simple scatter plots with NINV2 against model variables 
    
    # FUNCTION 1 --------------------------------------------------------------
    is_outlier <- function(x, y) {
      return(x < quantile(x, 0.01, na.rm=TRUE) - 1.5 * IQR(x, na.rm=TRUE) |
               x > quantile(x, 0.99, na.rm=TRUE) + 1.5 * IQR(x, na.rm=TRUE) |
               y < quantile(y, 0.01, na.rm=TRUE) - 1.5 * IQR(y, na.rm=TRUE) |
               y > quantile(y, 0.99, na.rm=TRUE) + 1.5 * IQR(y, na.rm=TRUE))
    }
    
    # FUNCTION 2 --------------------------------------------------------------
    gner_figure <- function(x, y, xlab, ylab, plot){
      a <- cor(x, y, use = "complete.obs")
      b <- cor(x, y, use = "complete.obs")
      out <- is_outlier(y=y, x=x) # find outlier by the rule defined in FUNCTION 1
      pdf(file=paste("saving_plot",plot,".pdf"), width = 10, height = 7.44)
      plot(x, y, 
           ylim=range(y, na.rm=TRUE), 
           xlim=range(x, na.rm=TRUE), 
           ylab="NINV2", xlab="log GDPpce", 
           main=paste("Scatterplot of",ylab,"vs",xlab),
           pch=ifelse(out==TRUE, 19, 1)) # plot filled circles for OECD cases
      abline(h=mean(y, na.rm=TRUE), lty=2)
      abline(v=mean(x, na.rm=TRUE), lty=2)
      text(x[out], y[out], labels=dat$CName[out], pos=4, cex=0.5) # label the country name of outlier
      dev.off()
      print(a)
      print(b)
    }
    
    #   lagged per capita GDP
    
    gner_figure(dat$logGDPpce, dat$NINV2, "log GDPpce", "NINV2", "1")
    gner_figure(dat$logGDPpce, dat$NINV2, "log GDPpco", "NINV2", "2")
    
    #   growth rates of labor and employment
    
    gner_figure(dat$grL, dat$NINV2, "Growth Rate of Labor", "NINV2", "3")
    gner_figure(dat$grE, dat$NINV2, "Growth Rate of Employment", "NINV2", "4")
    
    #   growth rates of TFP
    
    gner_figure(dat$grTFP1, dat$NINV2, "Growth rate of TFP1", "NINV2", "5")
    gner_figure(dat$grTFP2, dat$NINV2, "Growth rate of TFP2", "NINV2", "6")
    gner_figure(dat$grTFP3, dat$NINV2, "Growth rate of TFP3", "NINV2", "7")
    gner_figure(dat$grTFP4, dat$NINV2, "Growth rate of TFP4", "NINV2", "8")
    
    #   capital's share of income
    
    gner_figure(dat$CapShr, dat$NINV2, "Capital Share", "NINV2", "9")
    
    #   measures of capital taxation
    
    gner_figure(dat$TaxGDP, dat$NINV2, "Taxes as % GDP", "NINV2", "10")
    gner_figure(dat$CorpGDP, dat$NINV2, "Corp. Taxes as % GDP", "NINV2", "11")
    gner_figure(dat$CorpTax, dat$NINV2, "Corp. Taxes as % Total tAXES", "NINV2", "12")
    gner_figure(dat$BrCapTax, dat$NINV2, "Broad Cap. Taxes as % Total tAXES", "NINV2", "13")
    gner_figure(dat$EMCapTax, dat$NINV2, "Eff. Marg. Cap. Taxes as % Total tAXES", "NINV2", "14")
    
    #   control variables
    
    gner_figure(dat$Open, dat$NINV2, "Openness", "NINV2", "15")
    gner_figure(dat$GovShr, dat$NINV2, "Gov. Share of GDP", "NINV2", "16")
    gner_figure(dat$Infl, dat$NINV2, "Inflation", "NINV2", "17")
    gner_figure(dat$grHC, dat$NINV2, "Growth Rate of HC", "NINV2", "18")
    gner_figure(dat$PriceInv, dat$NINV2, "Relative Price of Investment", "NINV2", "19")
    
    
    