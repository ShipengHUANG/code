# 本代码的用途：判断日收盘价是否连续突破AMA+a*过去m天AMA的标准差。
# 只需改变变量n1、n2、N1、m、a、b的值即可快速进行任意调试，结合图可以更加直观看出

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties  # 导入FontProperties

# matplot设置
font = FontProperties(fname="SimHei.ttf", size=14)  # 设置字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 显示中文标签
plt.rcParams['axes.unicode_minus'] = False

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)

# 参数设置
n1 = 2  # AMA短周期
n2 = 30  # AMA长周期
D = 10 # 变化值天数
L = 20  # 标差周期
M = 1.5  # 标差倍数
b = 2  # 连续突破天数
start = ''  # 起始日期
end = ''  # 结束日期


# 建立类，后可以实体化为具体债市指标（国债利率/期货合约价）
class BreakerPoint(object):

    # 初始化数据
    def __init__(self, indexes, start, end):
        # 测试指数代码，起始日、结束日
        self.indexes = indexes
        self.start, self.end = start, end

    # 计算AMA
    def calcAMA(self, n1, n2, D):

        # 计算平滑常数SC
        Fast_SC = 2 / (n1 + 1)
        Slow_SC = 2 / (n2 + 1)

        # 建容器
        ER = np.zeros(len(self.indexes) - D)
        SSC = np.zeros(len(self.indexes) - D)
        AMA = np.zeros(len(self.indexes) - D).astype(np.float64)
        AMA[0] = self.indexes.iloc[0][0]

        # 计算效率比ER、缩放平滑常数SSC、自适应移动均线AMA
        for i in range(self.indexes.shape[0] - D):
            Delta = abs(self.indexes.iloc[i][0] - self.indexes.iloc[i + D][0])
            Volatility = abs(self.indexes.iloc[i][0] - self.indexes.iloc[i + 1][0])

            for j in range(D - 1):
                Volatility = Volatility + abs(self.indexes.iloc[i + j + 1][0] - self.indexes.iloc[i + j + 2][0])

            ER[i] = Delta / Volatility
            SSC[i] = 2 * (ER[i] * (Fast_SC - Slow_SC) + Slow_SC)

            if i > 0:
                AMA[i] = AMA[i - 1] + SSC[i] * (self.indexes.iloc[i][0] - AMA[i - 1])

        return ER, SSC, AMA

    # 判断突破点
    def identBreak(self, n1, L, M, AMA):

        # 建容器
        SD = np.zeros(len(self.indexes) - n1 - L)
        AMAUb = np.zeros(len(self.indexes) - n1 - L)
        AMALb = np.zeros(len(self.indexes) - n1 - L)
        UBreaker = np.zeros(len(self.indexes) - n1 - L)
        LBreaker = np.zeros(len(self.indexes) - n1 - L)

        # 上下突破判断
        for i in range(0, len(self.indexes) - n1 - L):
            Small_AMA = AMA[i:i + L]
            SD[i] = np.std(Small_AMA)
            AMAUb[i] = AMA[i] + M * SD[i]
            AMALb[i] = AMA[i] - M * SD[i]

            if self.indexes.iloc[i][0] > AMAUb[i]:
                UBreaker[i] = 1

            elif self.indexes.iloc[i][0] < AMALb[i]:
                LBreaker[i] = 1

        return AMAUb, AMALb, UBreaker, LBreaker

    # 判断是否连续b天突破
    def ContBreakthroughs(self, n1, L, b, UBreaker, LBreaker):

        # 建容器
        Sum_UBreaker = np.zeros(len(self.indexes) - n1 - L - b)
        Sum_LBreaker = np.zeros(len(self.indexes) - n1 - L - b)
        ContUBreaker = np.zeros(len(self.indexes) - n1 - L - b)
        ContLBreaker = np.zeros(len(self.indexes) - n1 - L - b)

        # 累计突破点
        for i in range(0, len(self.indexes) - n1 - L - b):
            Small_UBreaker = UBreaker[i:i + b]
            Sum_UBreaker[i] = np.sum(Small_UBreaker)
            Small_LBreaker = LBreaker[i:i + b]
            Sum_LBreaker[i] = np.sum(Small_LBreaker)

            if Sum_UBreaker[i] == b:
                ContUBreaker[i] = self.indexes.iloc[i][0]

            if Sum_LBreaker[i] == b:
                ContLBreaker[i] = self.indexes.iloc[i][0]

        Bull = pd.Series(ContUBreaker, index=self.indexes.drop(Date[len(self.indexes) - n1 - L - b:]).index)
        Bear = pd.Series(ContLBreaker, index=self.indexes.drop(Date[len(self.indexes) - n1 - L - b:]).index)


        return Bull, Bear


# 读取文件并按时间倒序调整顺序
df = pd.DataFrame(pd.read_excel('data.xlsx', header=3, index_col=0))
df = df.iloc[::-1]
Date = df.index

# 实例化运行
market = BreakerPoint(df, start, end)
ER, SSC, AMA = market.calcAMA(n1, n2, D)
AMAUb, AMALb, UBreaker, LBreaker = market.identBreak(D, L, M, AMA)
Bull, Bear = market.ContBreakthroughs(D, L, b, UBreaker, LBreaker)


# Output Results

# 1. transform the upper/lower bounds
TAMAUb = pd.Series(AMAUb, index=df.drop(Date[len(df) - D - L:]).index)
TAMALb = pd.Series(AMALb, index=df.drop(Date[len(df) - D - L:]).index)
TAMA = pd.Series(AMA, index=df.drop(Date[len(df) - D:]).index)
print('max=', TAMAUb.max())
print('min=', TAMALb.min())

# 2. set figure
fig = plt.figure(figsize=(25, 10))

# # 2.1 set sub_plot_1
ax1 = fig.add_subplot(221)
ax1.plot(df, label='收盘价', ls='solid', c='slateblue')
ax1.plot(TAMA, label='KAMA', ls='dashed', c='#C00000')
ax1.plot(TAMAUb, label='R_Breaker上边界', ls='dashed', c='#C00000')
ax1.plot(TAMALb, label='R_Breaker下边界', ls='dashed', c="#00B0F0")
ax1.legend()
plt.title('10年期国债期货日收盘价及上下界限')
plt.xlabel('日期')
plt.ylabel('收盘价')
plt.ylim(91, 105)

# # 2.2 set sub_plot_2
ax2 = fig.add_subplot(222)
ax2.plot(df, label='收盘价', ls='solid', c='#002060')
ax2.plot(Bull, linestyle='', label='牛市信号', marker='o', markersize=5, c="#C00000")
ax2.plot(Bear, linestyle='', label='熊市信号', marker='o', markersize=5, c="#00B0F0")
ax2.legend()
plt.title('10年期国债期货日收盘价及牛熊信号')
plt.xlabel('日期')
plt.ylabel('收盘价')
plt.ylim(91, 105)

# 3. save and show the plot
plt.savefig('10年期国债期货日收盘价及突破界限')
plt.show()
