clear all;clc;
filename = 'duration_data.xlsx';
strcat('duration_data','...is running...')

%============UPDATE THE INPUTS!!!============
dtRange = 'A2:A2452';
xlRange= 'B2:I2452';
csRange= 'B2:H2452';
%========================!=================

dt=readtable(filename,'Sheet',1,'Range',dtRange);
SheetNm={'Banks','Insurance','Funds','Securities','Overseas','Trusts','CS_Index'};
n=size(dt,1);
inputs=zeros(n+1,9,7);
lamda=20-1; %regression window
dt(1:lamda,:)=[];
for i=1:7
   if i<7
        inputs(:,1:8,i)=readmatrix(filename,'Sheet',SheetNm{i},'Range',xlRange);
   else
        inputs(:,1:7,i)=readmatrix(filename,'Sheet',SheetNm{i},'Range',csRange);
   end
end

for j=1:6
    for i=1:n-lamda
        mdl = fitlm(inputs(i:i+lamda,8,j),inputs(i:i+lamda,7,j),'intercept',false);
        inputs(i+lamda,9,j)=mdl.Coefficients.Estimate(1);
        clear mdl
    end
end

lb = zeros(1,6);
ub = ones(1,6);
Aeq = ones(1,6);
beq = 1;
%x0 = ones(1,6)./6;
er=0;
coeff = zeros(n-lamda,10,6);
% 10th is adjusted duration; 9th is original duration; 8th is R-square; 
% 6th is original 10yr+ beta;7th is adjusted 10yr+ beta

for j=1:6
    for i=2:n-lamda
            Y=inputs(i:i+lamda,1,j);
            X=inputs(i:i+lamda,2:7,j);
            try
                [wsout,~,residual]= lsqlin(X,Y,[],[],Aeq,beq,lb,ub);
                coeff(i,1:6,j)=wsout';
                coeff(i,7,j)=inputs(i+lamda,9,j)*coeff(i,6,j);       
                coeff(i,8,j)=1-power(norm(residual),2)/power(norm(Y-mean(Y,1)),2);

            catch ME
                coeff(i,1:6,j)=coeff(i-1,1:6,j); 
                coeff(i,7,j)=coeff(i-1,7,j);
                residual = Y - X*coeff(i,1:6,j)';
                er=er+1;
            end
            
             coeff(i,8,j)=1-power(norm(residual),2)/power(norm(Y-mean(Y,1)),2);
             dur=inputs(i+lamda,2:7,7);
             adj_dur_beta=[coeff(i,1:5,j) coeff(i,7,j)]';
             coeff(i,9,j)=dur*coeff(i,1:6,j)';
             coeff(i,10,j)=dur*adj_dur_beta;
    end
end




 
newName=strcat('duration_data_',date(), '.xlsx');
if exist(newName, 'file')
    delete(newName);
end
copyfile(filename, newName)

header={'Date','<1yr beta','1-3yr beta','3-5yr beta','5-7yr beta','7-10yr beta','>10yr beta'...
    ,'>10yr adj beta','R-square','duration','adj duration'};
header_stat_y={'Count','Mean','StDev','Max','75th','Median','25th' ,'Min'}';
header_stat_x={'>10yr beta' ,'>10yr adj beta','R-square','duration','adj duration'};

for j=1:6
    writecell(header,newName,'Sheet',SheetNm{j},'Range','K2');
    writematrix(dt.x____,newName,'Sheet',SheetNm{j},'Range','K3');
    writematrix(coeff(:,1:10,j),newName,'Sheet',SheetNm{j},'Range','L3');
    z=coeff(:,6:10,j);
    stat_summary=[ size(z,1).*ones(1,5);mean(z);std(z);max(z);...
    prctile(z,75);median(z);prctile(z,25) ;min(z) ];
    writecell(header_stat_y,newName,'Sheet',SheetNm{j},'Range','Y3');
    writecell(header_stat_x,newName,'Sheet',SheetNm{j},'Range','Z2');
    writematrix(stat_summary,newName,'Sheet',SheetNm{j},'Range','Z3');
end


% >3yr funds
three_year_funds_dur = zeros(n-lamda,2);
for i=2:n-lamda
    transitory1=[];
    three_year_funds_dur_beta=coeff(i,3:6,3)'./sum(coeff(i,3:6,3));
    three_year_funds_dur(i,1)=inputs(i+lamda,4:7,7)*three_year_funds_dur_beta;
    transitory1 = [coeff(i,3:5,3) coeff(i,7,3)]';
    three_year_funds_adj_dur_beta=transitory1./sum(transitory1);
    three_year_funds_dur(i,2)=inputs(i+lamda,4:7,7)*three_year_funds_adj_dur_beta;   
end

header_funds={'Date','<1yr beta','1-3yr beta','3-5yr beta','5-7yr beta','7-10yr beta','>10yr beta'...
    ,'>10yr adj beta','R-square','duration','adj duration','>3yr duration','>3yr adj duration'};
writecell(header_funds,newName,'Sheet','Funds','Range','K2');
writematrix(three_year_funds_dur,newName,'Sheet','Funds','Range','V3');

[B,idx]=sort(dt.x____,'descend');
writecell({'Date'},newName,'Sheet','Dates','Range','E3');
%writecell({'CS_Index','>3yr Funds'},newName,'Sheet','Dates','Range','L3');
writecell({'CS_Index'},newName,'Sheet','Dates','Range','L3');
writematrix(B,newName,'Sheet','Dates','Range','E4');
writecell(SheetNm,newName,'Sheet','Dates','Range','F3');
locat_header={'F4','G4','H4','I4','J4','K4'};
for j =1:6
    transitory2=[];
    transitory2=coeff(idx,9,j);
    writematrix(transitory2,newName,'Sheet','Dates','Range',locat_header{j});
end

% transitory3=[];
% transitory3=three_year_funds_dur(idx,1);
% writematrix(transitory3,newName,'Sheet','Dates','Range','M4');

transitory4=[];
index_dur=inputs(lamda+1:end,1,7);
transitory4=index_dur(idx,:);
writematrix(transitory4,newName,'Sheet','Dates','Range','L4');

figure;
subplot(2,3,1)
plot(dt.x____,coeff(:,9,1));
title('Original Duration of Banks')
subplot(2,3,2)
plot(dt.x____,coeff(:,9,2));
title('Original Duration of Insurance')
subplot(2,3,3)
plot(dt.x____,coeff(:,9,3));
title('Original Duration of Funds')
subplot(2,3,4)
plot(dt.x____,coeff(:,9,4));
title('Original Duration of Securities')
subplot(2,3,5)
plot(dt.x____,coeff(:,9,5));
title('Original Duration of Overseas')
subplot(2,3,6)
plot(dt.x____,coeff(:,9,6));
title('Original Duration of Trusts')


% figure;
% subplot(2,3,1)
% plot(dt.x____,coeff(:,8,1));
% title('R-Square of Banks')
% subplot(2,3,2)
% plot(dt.x____,coeff(:,8,2));
% title('R-Square of Insurance')
% subplot(2,3,3)
% plot(dt.x____,coeff(:,8,3));
% title('R-Square of Funds')
% subplot(2,3,4)
% plot(dt.x____,coeff(:,8,4));
% title('R-Square of Securities')
% subplot(2,3,5)
% plot(dt.x____,coeff(:,8,5));
% title('R-Square of Overseas')
% subplot(2,3,6)
% plot(dt.x____,coeff(:,8,6));
% title('R-Square of Trusts')
    
% X=rand(6,1)
% Y=2+5*X+norminv(rand(6,1),0,1)
% 
% mdl = fitlm(X,Y)
% mdl.Rsquared
% 1-mdl.SSE/mdl.SST
% 
% residual=Y-mdl.Fitted
% mdl.Residuals.Raw
% 
% mdl.SSE
% sum(residual.*residual)
% 
% w=Y-mean(Y,1);
% sum(w.*w)
% power(norm(Y-mean(Y,1)),2)
% mdl.SST

