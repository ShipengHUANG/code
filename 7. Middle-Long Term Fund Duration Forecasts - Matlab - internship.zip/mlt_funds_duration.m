clear all;clc;
filename = 'medium_long_term_funds_duration_data.xlsx';
strcat('medium_long_term_funds_duration_data','...is running...')

%============UPDATE THE INPUTS!!!============
idxRange = 'A4:C1889'; %medium long term funds Wind Index
csRange= 'B6:H1889'; %CS Index returns and partial durations
fundsRange= 'B5:ASB1889'; %selected funds NAVs
%========================!=================

idx=readtable(filename,'Sheet','Dates','Range',idxRange);
idx=idx(2:end,:);
n=size(idx,1);

CS_Index_Ret=readmatrix(filename,'Sheet','CS_Index_Ret','Range',csRange);
CS_Index_Dur=readmatrix(filename,'Sheet','CS_Index_Dur','Range',csRange);
Funds_NAV=readmatrix(filename,'Sheet','Funds','Range',fundsRange);
Funds_Ret   = (Funds_NAV(2:end,:) ./ Funds_NAV(1:end-1,:) - 1)*100;
numFunds=size(Funds_Ret,2);
clear Funds_NAV;

lamda=30-1; %regression window-1
lb = zeros(1,6);
ub = ones(1,6);
Aeq = ones(1,6);
beq = 1;
er=0;
coeff_fund = nan(n-lamda,8,numFunds);% 8th is duration; 7th is R-square; 
x_dt=idx.x____(lamda+1:end,1);%used for plotting figures;


%medium_long_term_funds_wind_index
coeff_idx=nan(n-lamda,8);

for i=1820:n-lamda %date

            strcat('medium_long_term_funds_wind_index','...is running...')
            Y=table2array(idx(i:i+lamda,3));
            X=CS_Index_Ret(i:i+lamda,2:7);    

            if any(isnan(Y))
                    i=i+1;
            else                
                    try
                        [wsout,~,residual]= lsqlin(X,Y,[],[],Aeq,beq,lb,ub);
                        %[wsout,~,residual]= lsqlin(X,Y,[],[],[],[],lb,ub);
                        coeff_idx(i,1:6)=wsout';  
                    catch ME
                        coeff_idx(i,1:6)=coeff_idx(i-1,1:6); 
                        residual = Y - X*coeff_idx(i,1:6)';
                        er=er+1;
                    end                    
                    coeff_idx(i,7)=1-power(norm(residual),2)/power(norm(Y-mean(Y,1)),2);
                     if coeff_idx(i,7 )<0
                             coeff_idx(i,7 )=0;
                     end
                     dur=CS_Index_Dur(i+lamda,2:7);
                     coeff_idx(i,8)=dur*coeff_idx(i,1:6)';                     
            end

end


% fund level
for j=1:numFunds %number of funds

    for i=1820:n-lamda %date
                strcat('No. ' ,num2str(j ),' / ',num2str(numFunds) ...
                    ,'...Fund...is running...with date i->... ',num2str(i),' / ',num2str(n-lamda))
                
                Y=Funds_Ret(i:i+lamda,j);
                X=CS_Index_Ret(i:i+lamda,2:7);    
                
                if any(isnan(Y))
                        i=i+1;            
                else                    
                        try
                            [wsout,~,residual]= lsqlin(X,Y,[],[],Aeq,beq,lb,ub);
                            coeff_fund(i,1:6,j)=wsout';  
                        catch ME
                            coeff_fund(i,1:6,j)=coeff_fund(i-1,1:6,j); 
                            residual = Y - X*coeff_fund(i,1:6,j)';
                            er=er+1;
                        end                        
                         coeff_fund(i,7,j)=1-power(norm(residual),2)/power(norm(Y-mean(Y,1)),2);
                         if coeff_fund(i,7,j)<0
                             coeff_fund(i,7,j)=0;
                         end
                         dur=CS_Index_Dur(i+lamda,2:7);
                         coeff_fund(i,8,j)=dur*coeff_fund(i,1:6,j)';                         
                end
                
    end
    
end

Funds_Stats_Mean = nan(n-lamda,8);
Funds_Stats_Std = nan(n-lamda,8);
Funds_Stats_Median = nan(n-lamda,8);

for i=1820:n-lamda %date
    
        for j=1:8 %coefficients
            
            Funds_Stats_Mean(i,j)=nanmean(coeff_fund(i,j,:));
            Funds_Stats_Std(i,j)=nanstd(coeff_fund(i,j,:));
            Funds_Stats_Median(i,j)=nanmedian(coeff_fund(i,j,:));

        end
end

%export to excel
 
newName=strcat('medium_long_term_funds_duration_data_',date(), '.xlsx');
if exist(newName, 'file')
    delete(newName);
end
copyfile(filename, newName);


avger=10-1;  %moving average window for duration time series

wind_idx_dur = coeff_idx(:,8);
transitory1=coeff_idx(:,8);
transitory1(avger+1:end,:)=movmean(transitory1,avger+1,'Endpoints','discard');
transitory1(1:avger,:)=nan;
wind_idx_dur_ma = transitory1;
%figure;
%plot(x_dt,wind_idx_dur,x_dt,wind_idx_dur_ma );
%title('Duration of Wind Index')

fund_dur_median = Funds_Stats_Median(:,8);
transitory2=Funds_Stats_Median(:,8);
transitory2(avger+1:end,:)=movmean(transitory2,avger+1,'Endpoints','discard');
transitory2(1:avger,:)=nan;
fund_dur_median_ma = transitory2;

fund_dur_mean = Funds_Stats_Mean(:,8);
transitory4=Funds_Stats_Mean(:,8);
transitory4(avger+1:end,:)=movmean(transitory4,avger+1,'Endpoints','discard');
transitory4(1:avger,:)=nan;
fund_dur_mean_ma = transitory4;

fund_dur_std = Funds_Stats_Std(:,8);
transitory3=Funds_Stats_Std(:,8);
transitory3(avger+1:end,:)=movmean(transitory3,avger+1,'Endpoints','discard');
transitory3(1:avger,:)=nan;
fund_dur_std_ma = transitory3;


%header_funds={'Date','median duration','median duration ma(20)',...
%    'stdev duration','stdev duration ma(20)',...
%    'R-square','wind index duration','wind index duration ma(20)','wind index R-square'};
%writecell(header_funds,newName,'Sheet','Results','Range','A3');

[B,sort_id]=sort(x_dt,'descend');
writematrix(B,newName,'Sheet','Results','Range','A5');

output=horzcat(fund_dur_median(sort_id,:)       ,     fund_dur_median_ma(sort_id,:)   ,...
                fund_dur_std (sort_id,:)         ,           fund_dur_std_ma(sort_id,:)       ,     ...
                Funds_Stats_Median(sort_id,7)    ,  wind_idx_dur(sort_id,:)  ,  ...
                wind_idx_dur_ma(sort_id,:)         ,   coeff_idx(sort_id,7)  ,   ...
                fund_dur_mean(sort_id,:)       ,     fund_dur_mean_ma(sort_id,:)   ,...              
                fund_dur_std (sort_id,:) ./fund_dur_median(sort_id,:)       ,   ...
                fund_dur_std_ma(sort_id,:)./fund_dur_mean_ma(sort_id,:)                  );
writematrix(output,newName,'Sheet','Results','Range','B5');


%header_stats_x={ 'median duration','median duration ma(20)',...
%    'stdev duration','stdev duration ma(20)',...
%    'R-square','wind index duration','wind index duration ma(20)','wind index R-square'};
%header_stats_y= {'mean','std','max','median','min'}';
%writecell(header_stats_x,newName,'Sheet','Results','Range','L3');
%writecell(header_stats_y,newName,'Sheet','Results','Range','K5');
percentile_window=252*5;
transitory4=output(1:percentile_window,1:8);
stat_summary=[  mean(transitory4);std(transitory4);max(transitory4);...
    prctile(transitory4,75);median(transitory4);prctile(transitory4,25) ;min(transitory4) ];
%writematrix(stat_summary,newName,'Sheet','Results','Range','S6');



figure;
subplot(1,2,1)
plot(x_dt,fund_dur_median,x_dt,fund_dur_median_ma)
title('Median: Duration of Fund Level');
subplot(1,2,2)
plot(x_dt,fund_dur_std,x_dt,fund_dur_std_ma)
title('StDev: Duration of Fund Level');

figure;
subplot(1,2,1)
plot(x_dt,fund_dur_median,x_dt,fund_dur_median_ma);
title('Duration of Fund Level');
subplot(1,2,2)
plot(x_dt,wind_idx_dur,x_dt,wind_idx_dur_ma);
title('Duration of Wind Index');


figure;
plot(x_dt,fund_dur_median_ma,x_dt,wind_idx_dur_ma);
title('Duration of Fund(Blue) and Index(Orange) Level');


figure;
subplot(1,2,1)
plot(x_dt,Funds_Stats_Median(:,7));
title('R-Square of Fund Level');
subplot(1,2,2)
plot(x_dt,coeff_idx(:,7));
title('R-Square of Wind Index');
